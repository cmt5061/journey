import { useState, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════════
   CONSTANTS & CONFIG
═══════════════════════════════════════════════════════════════ */
const ACT_TYPES = [
  { id: "flight",     label: "Flight",      icon: "✈️" },
  { id: "train",      label: "Train / Bus", icon: "🚅" },
  { id: "hotel",      label: "Hotel",       icon: "🏨" },
  { id: "restaurant", label: "Restaurant",  icon: "🍽️" },
  { id: "attraction", label: "Attraction",  icon: "🎨" },
  { id: "transit",    label: "Transit",     icon: "🚇" },
  { id: "free",       label: "Free Time",   icon: "🕐" },
  { id: "other",      label: "Other",       icon: "📌" },
];

const COST_CATS = ["Food", "Transport", "Lodging", "Activities", "Shopping", "Other"];
const BLOCKS    = ["morning", "afternoon", "evening"];
const BLOCK_META = {
  morning:   { label: "Morning",   icon: "🌅", accent: "#d4a853", dim: "rgba(212,168,83,0.12)"   },
  afternoon: { label: "Afternoon", icon: "☀️", accent: "#e08a4a", dim: "rgba(224,138,74,0.12)"  },
  evening:   { label: "Evening",   icon: "🌙", accent: "#8e7dcf", dim: "rgba(142,125,207,0.12)" },
};
const CITY_PALETTE = ["#4e7fa6","#6b5da6","#4e9478","#a66040","#7a5a8a","#4a7a6a","#9a7040"];
const STATUS_META = {
  planning: { label: "Planning", color: "#d4a853" },
  active:   { label: "On Trip",  color: "#5cb87a" },
  complete: { label: "Complete", color: "#6b7a9a" },
};

/* ── Checklist categories & priorities ─────────────────────── */
const PREP_CATS = ["Documents", "Packing", "Bookings", "Health", "Money", "Tech", "Notifications", "Other"];
const PREP_PRIO = [
  { id: "high",   label: "High",   color: "#e07070" },
  { id: "normal", label: "Normal", color: "#d4a853" },
  { id: "low",    label: "Low",    color: "#4a4f6a" },
];
const PREP_SCOPES = [
  { id: "trip", label: "Trip-level",     icon: "✈️" },
  { id: "city", label: "City-specific",  icon: "🏙️" },
  { id: "day",  label: "Day-specific",   icon: "📅" },
];

/* ── Built-in checklist templates ────────────────────────────── */
const BUILTIN_TEMPLATES = [
  {
    id: "tpl-international", name: "International Trip", icon: "🌍",
    description: "Passports, visas, forex, travel insurance — the essentials before any overseas trip.",
    isBuiltIn: true,
    items: [
      { id: "bi1",  text: "Check passport expiry (6+ months past return date)",   category: "Documents", priority: "high"   },
      { id: "bi2",  text: "Apply for visas if required",                           category: "Documents", priority: "high"   },
      { id: "bi3",  text: "Make copies of passport, visa, insurance (cloud + paper)", category: "Documents", priority: "high" },
      { id: "bi4",  text: "Purchase travel insurance",                             category: "Bookings",  priority: "high"   },
      { id: "bi5",  text: "Notify bank and credit cards of travel dates",          category: "Money",     priority: "high"   },
      { id: "bi6",  text: "Get foreign currency or confirm no-fee card",           category: "Money",     priority: "normal" },
      { id: "bi7",  text: "Check vaccination requirements / get vaccines",         category: "Health",    priority: "high"   },
      { id: "bi8",  text: "Fill prescriptions for entire trip + extra",            category: "Health",    priority: "high"   },
      { id: "bi9",  text: "Download offline maps (Google Maps / Maps.me)",         category: "Tech",      priority: "normal" },
      { id: "bi10", text: "Set up international phone plan or buy local SIM",      category: "Tech",      priority: "normal" },
      { id: "bi11", text: "Pack universal power adapter",                          category: "Packing",   priority: "normal" },
      { id: "bi12", text: "Arrange airport transportation (both ends)",            category: "Bookings",  priority: "normal" },
      { id: "bi13", text: "Set mail hold or ask neighbor to collect",              category: "Notifications", priority: "low" },
      { id: "bi14", text: "Put utilities / subscriptions on hold if long trip",   category: "Notifications", priority: "low" },
      { id: "bi15", text: "Share itinerary with emergency contact",                category: "Documents", priority: "normal" },
    ],
  },
  {
    id: "tpl-beach", name: "Beach Trip", icon: "🏖️",
    description: "Sun, sand, and nothing forgotten — from reef-safe sunscreen to snorkel gear.",
    isBuiltIn: true,
    items: [
      { id: "bb1",  text: "Pack reef-safe sunscreen (SPF 50+)",                   category: "Packing",   priority: "high"   },
      { id: "bb2",  text: "Pack swimsuits (2+ recommended)",                      category: "Packing",   priority: "high"   },
      { id: "bb3",  text: "Beach towels or confirm hotel provides them",           category: "Packing",   priority: "normal" },
      { id: "bb4",  text: "Waterproof phone case or dry bag",                     category: "Packing",   priority: "normal" },
      { id: "bb5",  text: "Snorkel / fins (or research rental options)",           category: "Packing",   priority: "low"    },
      { id: "bb6",  text: "After-sun lotion / aloe vera",                         category: "Health",    priority: "normal" },
      { id: "bb7",  text: "Insect repellent",                                     category: "Health",    priority: "normal" },
      { id: "bb8",  text: "Polarized sunglasses and hat",                         category: "Packing",   priority: "normal" },
      { id: "bb9",  text: "Water shoes / flip flops",                             category: "Packing",   priority: "normal" },
      { id: "bb10", text: "Book water activities in advance (diving, kayak, etc.)", category: "Bookings", priority: "normal" },
      { id: "bb11", text: "Research beach conditions / jellyfish season",          category: "Other",     priority: "low"    },
      { id: "bb12", text: "Portable charger and solar panel option",               category: "Tech",      priority: "low"    },
    ],
  },
  {
    id: "tpl-roadtrip", name: "Road Trip", icon: "🚗",
    description: "Car checks, playlists, snack bags — everything for a long drive.",
    isBuiltIn: true,
    items: [
      { id: "rr1",  text: "Car service check (oil, tires, wipers, brakes)",       category: "Other",     priority: "high"   },
      { id: "rr2",  text: "Check spare tire and jumper cables",                   category: "Other",     priority: "high"   },
      { id: "rr3",  text: "Download offline maps for entire route",               category: "Tech",      priority: "high"   },
      { id: "rr4",  text: "Roadside assistance membership (AAA, etc.)",           category: "Documents", priority: "high"   },
      { id: "rr5",  text: "Pack reusable water bottles and cooler",               category: "Packing",   priority: "normal" },
      { id: "rr6",  text: "Snacks for the road",                                  category: "Packing",   priority: "normal" },
      { id: "rr7",  text: "Car phone mount and charging cables",                  category: "Tech",      priority: "normal" },
      { id: "rr8",  text: "Download podcasts / audiobooks / playlists offline",   category: "Tech",      priority: "normal" },
      { id: "rr9",  text: "Book accommodations along route",                      category: "Bookings",  priority: "high"   },
      { id: "rr10", text: "Research gas station spacing on remote stretches",     category: "Other",     priority: "normal" },
      { id: "rr11", text: "First-aid kit",                                        category: "Health",    priority: "normal" },
      { id: "rr12", text: "Emergency cash",                                       category: "Money",     priority: "normal" },
      { id: "rr13", text: "Printed reservation confirmations (for spotty areas)", category: "Documents", priority: "low"    },
    ],
  },
  {
    id: "tpl-generic", name: "Travel Checklist", icon: "✅",
    description: "A solid baseline for any trip — the items you always forget until you're at the airport.",
    isBuiltIn: true,
    items: [
      { id: "gc1",  text: "Book flights / transportation",                        category: "Bookings",  priority: "high"   },
      { id: "gc2",  text: "Book accommodations for every night",                  category: "Bookings",  priority: "high"   },
      { id: "gc3",  text: "Confirm all reservation dates are correct",            category: "Bookings",  priority: "high"   },
      { id: "gc4",  text: "Check ID / travel documents are valid",                category: "Documents", priority: "high"   },
      { id: "gc5",  text: "Pack all medications",                                 category: "Health",    priority: "high"   },
      { id: "gc6",  text: "Pack chargers for all devices",                        category: "Tech",      priority: "normal" },
      { id: "gc7",  text: "Download entertainment for the journey",               category: "Tech",      priority: "low"    },
      { id: "gc8",  text: "Confirm carry-on only vs checked bag",                 category: "Packing",   priority: "normal" },
      { id: "gc9",  text: "Pack toiletries in TSA-compliant bag",                 category: "Packing",   priority: "normal" },
      { id: "gc10", text: "Set out-of-office email reply",                        category: "Notifications", priority: "normal" },
      { id: "gc11", text: "Arrange pet care / house sitter",                      category: "Notifications", priority: "normal" },
      { id: "gc12", text: "Check in online (24–48h before flight)",               category: "Bookings",  priority: "normal" },
      { id: "gc13", text: "Confirm transportation to airport",                    category: "Bookings",  priority: "normal" },
      { id: "gc14", text: "Pack snacks for travel day",                           category: "Packing",   priority: "low"    },
      { id: "gc15", text: "Portable battery / power bank",                        category: "Tech",      priority: "normal" },
    ],
  },
];

/* ═══════════════════════════════════════════════════════════════
   THEME
═══════════════════════════════════════════════════════════════ */
const C = {
  bg:        "#0c0e16", surface:  "#141720", surface2: "#1c2033",
  surface3:  "#242840", accent:   "#d4a853", accentBg: "rgba(212,168,83,0.10)",
  accentBdr: "rgba(212,168,83,0.25)", text: "#ede8e0", mid: "#8c91ae",
  dim:       "#4a4f6a", border:   "rgba(255,255,255,0.06)", ok: "#5cb87a",
  okBg:      "rgba(92,184,122,0.12)", okBdr: "rgba(92,184,122,0.25)",
  warn:      "#e07070", warnBg:   "rgba(224,112,112,0.12)", warnBdr: "rgba(224,112,112,0.25)",
  purple:    "#a78bfa", purpleBg: "rgba(167,139,250,0.12)", purpleBdr: "rgba(167,139,250,0.3)",
  teal:      "#4ecdc4", tealBg:   "rgba(78,205,196,0.12)",
};

const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { height: 100%; }
  ::-webkit-scrollbar { width: 4px; height: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: #252a42; border-radius: 2px; }
  input, textarea, select {
    background: ${C.surface2}; color: ${C.text}; border: 1px solid ${C.border};
    border-radius: 7px; padding: 8px 12px; font-family: 'DM Sans', sans-serif;
    font-size: 14px; outline: none; width: 100%; transition: border-color 0.15s;
  }
  input:focus, textarea:focus, select:focus { border-color: ${C.accentBdr}; }
  input[type=checkbox], input[type=radio] { width: auto; accent-color: ${C.accent}; }
  textarea { resize: vertical; line-height: 1.6; }
  select {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%234a4f6a'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 10px center; padding-right: 28px;
  }
  button { cursor: pointer; font-family: 'DM Sans', sans-serif; }
  a { color: ${C.accent}; text-decoration: none; }
  a:hover { text-decoration: underline; }
  @keyframes fadeSlideIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
  @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.55; } }
  @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }

  /* ── Scrollable tab bar ── */
  .tab-bar {
    display: flex;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    scroll-snap-type: x proximity;
  }
  .tab-bar::-webkit-scrollbar { display: none; }
  .tab-bar button { flex-shrink: 0; scroll-snap-align: start; }

  /* ── Scrollable horizontal strip (city ribbon, filter pills) ── */
  .h-scroll {
    display: flex;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    gap: 8px;
    padding-bottom: 4px;
  }
  .h-scroll::-webkit-scrollbar { display: none; }
  .h-scroll > * { flex-shrink: 0; }

  /* ── Mobile: full-screen bottom-sheet modals ── */
  @media (max-width: 600px) {
    .modal-inner {
      max-width: 100% !important;
      width: 100% !important;
      max-height: 93vh !important;
      border-radius: 20px 20px 0 0 !important;
      align-self: flex-end;
    }
    .modal-outer {
      align-items: flex-end !important;
      padding: 0 !important;
    }
  }

  /* ── Mobile: safe area + global padding ── */
  @media (max-width: 600px) {
    .page-pad   { padding: 16px !important; }
    .page-pad-t { padding: 16px 16px 0 !important; }
    .safe-bottom { padding-bottom: max(16px, env(safe-area-inset-bottom)) !important; }
  }

  /* ── Touch targets + iOS zoom prevention ── */
  @media (max-width: 768px) {
    button { min-height: 36px; }
    input, select, textarea { font-size: 16px !important; }
  }

  /* ── Day blocks: horizontal swipe on mobile ── */
  .day-block-scroll {
    display: flex;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    scroll-snap-type: x mandatory;
    gap: 14px;
  }
  .day-block-scroll::-webkit-scrollbar { display: none; }
  .day-block-scroll > * {
    flex-shrink: 0;
    scroll-snap-align: start;
  }
  @media (max-width: 640px) {
    .day-block-scroll > * { width: calc(100vw - 48px); }
  }
  @media (min-width: 641px) {
    .day-block-scroll > * { width: 280px; }
  }

  /* ── Grid helpers ── */
  @media (max-width: 640px) {
    .grid-2-mob-1 { grid-template-columns: 1fr !important; }
    .grid-3-mob-1 { grid-template-columns: 1fr !important; }
    .grid-4-mob-2 { grid-template-columns: 1fr 1fr !important; }
  }

  /* ── Trip top-bar on mobile ── */
  @media (max-width: 640px) {
    .trip-topbar-actions { display: none !important; }
    .trip-topbar-mobile  { display: flex !important; }
  }
  @media (min-width: 641px) {
    .trip-topbar-mobile { display: none !important; }
  }
`;

/* ── useMobile hook ─────────────────────────────────────────── */
function useMobile(breakpoint = 640) {
  const [mobile, setMobile] = useState(() => typeof window !== "undefined" && window.innerWidth < breakpoint);
  useEffect(() => {
    const handler = () => setMobile(window.innerWidth < breakpoint);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [breakpoint]);
  return mobile;
}


/* ═══════════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════════ */
const uid   = () => Math.random().toString(36).slice(2, 9);
const fmt   = (n, cur) => n > 0 ? `${cur} ${Number(n).toFixed(2)}` : "—";
const today = () => new Date().toISOString().split("T")[0];

const getPTODays = (start, end) => {
  if (!start || !end) return 0;
  let count = 0;
  const d = new Date(start + "T12:00:00Z");
  const e = new Date(end   + "T12:00:00Z");
  while (d <= e) {
    const dow = d.getUTCDay();
    if (dow !== 0 && dow !== 6) count++;
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return count;
};

const newActivity = (o = {}) => ({
  id: uid(), type: "other", title: "", time: "", duration: "", location: "",
  confirmation: "", transitSteps: "", references: [], addedOnTrip: false,
  isConfirmed: false, completed: false,
  cost: { estimated: "", confirmed: "", paidBy: "split", category: "Other", notes: "" },
  notes: "", ...o,
});

const newTodo = (o = {}) => ({ id: uid(), title: "", url: "", urlLabel: "", notes: "", status: "idea", ...o });
const makeDay = (date, label) => ({ id: uid(), date, label, reflection: "", blocks: { morning: [], afternoon: [], evening: [] } });
const makeCityDays = (nights, startStr) =>
  Array.from({ length: nights }, (_, i) => {
    const d = new Date(startStr + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + i);
    return makeDay(d.toISOString().split("T")[0], i === 0 ? "Arrival" : `Day ${i + 1}`);
  });

const newCity = (name, nights, startStr) => ({
  id: uid(), name, nights, notes: "", thingsToDo: [],
  days: makeCityDays(nights, startStr),
});

const newTrip = ({ title, startDate, endDate, currency = "USD", ptoDays = "" }) => ({
  id: uid(), title, startDate, endDate, currency, ptoDays,
  status: "planning", travelers: ["You", "Partner"],
  cities: [], tripNotes: "",
});

const getAllActivities = (trip) =>
  trip.cities.flatMap(c =>
    c.days.flatMap(d =>
      BLOCKS.flatMap(b =>
        d.blocks[b].map(a => ({ ...a, cityName: c.name, cityId: c.id, dayLabel: d.label, date: d.date, block: b, dayId: d.id }))
      )
    )
  );

const getTodayActivities = (trip) => {
  const t = today();
  return getAllActivities(trip).filter(a => a.date === t);
};

const getCurrentActivity = (allToday) => {
  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
  const timed = allToday.filter(a => a.time && !a.completed);
  const past  = timed.filter(a => a.time <= hhmm);
  const future= timed.filter(a => a.time >  hhmm);
  const current = past.length > 0 ? past[past.length - 1] : null;
  const next    = future.length > 0 ? future[0] : allToday.find(a => !a.completed && !a.time);
  return { current, next };
};

/* ═══════════════════════════════════════════════════════════════
   IMPORT / EXPORT UTILITIES
═══════════════════════════════════════════════════════════════ */
const JOURNEY_VERSION = "1.0";

// ── Helpers ──────────────────────────────────────────────────
const downloadFile = (filename, content, mime = "application/json") => {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

const slugify = (str) =>
  str.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// ── JSON Export ───────────────────────────────────────────────
const exportTripJSON = (trip) => {
  const payload = { _journey: JOURNEY_VERSION, exportedAt: new Date().toISOString(), trips: [trip] };
  downloadFile(`journey-${slugify(trip.title)}.json`, JSON.stringify(payload, null, 2));
};

const exportAllJSON = (trips) => {
  const payload = { _journey: JOURNEY_VERSION, exportedAt: new Date().toISOString(), trips };
  downloadFile(`journey-all-trips-${today()}.json`, JSON.stringify(payload, null, 2));
};

// ── CSV Export (budget) ───────────────────────────────────────
const exportBudgetCSV = (trip) => {
  const rows = [["Trip", "City", "Date", "Block", "Activity", "Type", "Confirmation", "Est. Cost", "Conf. Cost", "Paid By", "Category", "Cost Notes"]];
  getAllActivities(trip).forEach(a => {
    if (!a.cost?.estimated && !a.cost?.confirmed) return;
    rows.push([
      trip.title, a.cityName, a.date, BLOCK_META[a.block]?.label || a.block,
      a.title, a.type, a.confirmation || "",
      a.cost.estimated || "", a.cost.confirmed || "",
      a.cost.paidBy, a.cost.category, a.cost.notes || "",
    ]);
  });
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
  downloadFile(`journey-budget-${slugify(trip.title)}.csv`, csv, "text/csv");
};

// ── Markdown / Text Export ────────────────────────────────────
const exportItineraryMD = (trip) => {
  const lines = [];
  lines.push(`# ${trip.title}`);
  lines.push(`**Dates:** ${trip.startDate} → ${trip.endDate}  |  **PTO:** ${trip.ptoDays || "?"}  |  **Currency:** ${trip.currency}`);
  lines.push("");
  trip.cities.forEach(city => {
    lines.push(`## ${city.name} (${city.nights} nights)`);
    if (city.notes) lines.push(`> ${city.notes}`);
    lines.push("");
    city.days.forEach(day => {
      lines.push(`### ${day.label} — ${day.date}`);
      BLOCKS.forEach(bl => {
        const acts = day.blocks[bl];
        if (!acts.length) return;
        lines.push(`**${BLOCK_META[bl].label}**`);
        acts.forEach(a => {
          const t  = ACT_TYPES.find(x => x.id === a.type);
          const ts = a.time ? ` · ${a.time}` : "";
          const cn = a.confirmation ? ` · ✓ ${a.confirmation}` : "";
          lines.push(`- ${t?.icon || ""} **${a.title || "Untitled"}**${ts}${cn}`);
          if (a.location)     lines.push(`  📍 ${a.location}`);
          if (a.transitSteps) lines.push(`  🚇 ${a.transitSteps.split("\n").join("  \n  ")}`);
          if (a.notes)        lines.push(`  💬 ${a.notes}`);
        });
        lines.push("");
      });
      if (day.reflection) lines.push(`*Reflection: ${day.reflection}*\n`);
    });
    if (city.thingsToDo.length) {
      lines.push(`### Research Board — ${city.name}`);
      city.thingsToDo.forEach(t => {
        lines.push(`- [${t.status.toUpperCase()}] **${t.title}**${t.url ? ` — [link](${t.url})` : ""}`);
        if (t.notes) lines.push(`  ${t.notes}`);
      });
      lines.push("");
    }
  });
  if (trip.tripNotes) { lines.push("## Trip Reflections"); lines.push(trip.tripNotes); }
  downloadFile(`journey-itinerary-${slugify(trip.title)}.md`, lines.join("\n"), "text/markdown");
};

// ── JSON Import ───────────────────────────────────────────────
const readJSONFile = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = e => { try { resolve(JSON.parse(e.target.result)); } catch { reject(new Error("Invalid JSON file")); } };
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsText(file);
  });

const validateImport = (parsed) => {
  if (!parsed?._journey) throw new Error("Not a Journey export file.");
  if (!Array.isArray(parsed.trips) || parsed.trips.length === 0) throw new Error("No trips found in file.");
  parsed.trips.forEach(t => {
    if (!t.id || !t.title) throw new Error("Trip data is malformed (missing id or title).");
  });
  return parsed.trips;
};

// Re-stamp all IDs so imported trips never collide with existing ones
const restampIds = (trip) => {
  const idMap = {};
  const fresh = (old) => { if (!idMap[old]) idMap[old] = uid(); return idMap[old]; };
  return {
    ...trip,
    id: fresh(trip.id),
    cities: (trip.cities || []).map(c => ({
      ...c, id: fresh(c.id),
      thingsToDo: (c.thingsToDo || []).map(t => ({ ...t, id: fresh(t.id) })),
      days: (c.days || []).map(d => ({
        ...d, id: fresh(d.id),
        blocks: Object.fromEntries(
          Object.entries(d.blocks || {}).map(([bl, acts]) => [
            bl, (acts || []).map(a => ({ ...a, id: fresh(a.id), references: (a.references || []).map(r => ({ ...r, id: fresh(r.id) })) })),
          ])
        ),
      })),
    })),
  };
};

const newPrepItem = (o = {}) => ({
  id: uid(), text: "", category: "Other", notes: "",
  completed: false, completedAt: null,
  scope: "trip", cityId: null, dayId: null,
  priority: "normal", fromTemplate: null,
  ...o,
});

/* Stamp fresh IDs onto template items when importing into a trip */
const stampTemplateItems = (templateItems, fromTemplateId) =>
  templateItems.map(item => newPrepItem({
    text: item.text, category: item.category,
    priority: item.priority || "normal", notes: item.notes || "",
    fromTemplate: fromTemplateId,
  }));

const newCustomTemplate = (o = {}) => ({
  id: uid(), name: "", icon: "📋", description: "",
  isBuiltIn: false,
  items: [],
  ...o,
});

/* ═══════════════════════════════════════════════════════════════
   SAMPLE DATA
═══════════════════════════════════════════════════════════════ */
const SAMPLE = {
  id: "trip1", title: "Japan Spring 2025",
  startDate: "2025-03-28", endDate: "2025-04-09",
  currency: "USD", ptoDays: 9, status: "planning",
  travelers: ["You", "Partner"], tripNotes: "",
  cities: [
    {
      id: "c1", name: "Kyoto", nights: 4,
      notes: "Get IC card at KIX airport. JR Pass covers Haruka + most trains.",
      thingsToDo: [
        { id: "td1", title: "Fushimi Inari at sunrise", url: "https://www.fushimi.or.jp", urlLabel: "Official Site", notes: "Go before 7am — extremely crowded by 9.", status: "idea" },
        { id: "td2", title: "Nishiki Market food walk", url: "", urlLabel: "", notes: "Most stalls close ~6pm.", status: "planned" },
        { id: "td3", title: "Arashiyama bamboo grove", url: "", urlLabel: "", notes: "Consider booking a rickshaw.", status: "idea" },
        { id: "td4", title: "Philosopher's Path", url: "", urlLabel: "", notes: "Cherry blossoms in late March! Best late afternoon.", status: "done" },
      ],
      days: [
        {
          id: "day1", date: "2025-03-28", label: "Arrival Day", reflection: "Long flight but arrived smoothly. Haruka Express was a breeze.",
          blocks: {
            morning: [],
            afternoon: [{
              id: "a1", type: "flight", title: "Fly JFK → KIX", time: "13:00", duration: "14h 30m",
              location: "JFK T1 → KIX T1", confirmation: "JL4892", transitSteps: "", addedOnTrip: false,
              isConfirmed: true, completed: true, notes: "Seats 24A & 24B. Meal: vegetarian.",
              cost: { estimated: "1200", confirmed: "1200", paidBy: "you", category: "Transport", notes: "Booked on points" },
              references: [{ id: "r1", url: "https://www.jal.com", label: "JAL booking", notes: "" }],
            }],
            evening: [{
              id: "a2", type: "train", title: "Haruka Express → Kyoto Station", time: "04:30",
              duration: "75 min", location: "KIX Platform 5 → Kyoto Sta.",
              confirmation: "", addedOnTrip: false, isConfirmed: false, completed: false,
              transitSteps: "1. Board Haruka Ltd Express at KIX Platform 5.\n2. Ride ~75 min direct to Kyoto Station.\n3. Exit Kyoto Sta. — Karasuma exit toward hotel.",
              notes: "JR Pass covers this.", cost: { estimated: "28", confirmed: "", paidBy: "split", category: "Transport", notes: "JR Pass" },
              references: [],
            }],
          },
        },
        { id: "day2", date: "2025-03-29", label: "Day 2 — Temples", reflection: "",
          blocks: {
            morning: [{ id: "a3", type: "attraction", title: "Fushimi Inari", time: "06:30", duration: "2h", location: "Fushimi Ward", confirmation: "", addedOnTrip: false, isConfirmed: true, completed: false, transitSteps: "", notes: "Go very early!", cost: { estimated: "0", confirmed: "", paidBy: "split", category: "Activities", notes: "Free entry" }, references: [] }],
            afternoon: [],
            evening: [{ id: "a4", type: "restaurant", title: "Dinner at Nishiki Warai", time: "19:00", duration: "1h 30m", location: "Nishiki Market area", confirmation: "NW-2290", addedOnTrip: false, isConfirmed: true, completed: false, transitSteps: "", notes: "", cost: { estimated: "80", confirmed: "", paidBy: "split", category: "Food", notes: "" }, references: [] }],
          },
        },
        { id: "day3", date: "2025-03-30", label: "Day 3", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day4", date: "2025-03-31", label: "Day 4", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
      ],
    },
    {
      id: "c2", name: "Osaka", nights: 3,
      notes: "Dotonbori at night for all the neon. Osaka Amazing Pass for transport.",
      thingsToDo: [
        { id: "td5", title: "Dotonbori street food crawl", url: "", urlLabel: "", notes: "Best after dark — all the neon is on.", status: "idea" },
        { id: "td6", title: "Osaka Castle", url: "https://www.osakacastle.net", urlLabel: "Book online", notes: "Skip the interior — enjoy the grounds & moat.", status: "idea" },
        { id: "td7", title: "Kuromon Ichiba Market", url: "", urlLabel: "", notes: "Morning is best. Excellent fresh seafood.", status: "planned" },
      ],
      days: [
        { id: "day5", date: "2025-04-01", label: "Travel Day", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day6", date: "2025-04-02", label: "Day 2", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day7", date: "2025-04-03", label: "Day 3", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
      ],
    },
    {
      id: "c3", name: "Tokyo", nights: 4,
      notes: "Get Suica card at Shinjuku. Shibuya, Harajuku, Shinjuku are walkable together.",
      thingsToDo: [
        { id: "td8", title: "TeamLab Planets", url: "https://planets.teamlab.art", urlLabel: "Buy tickets NOW", notes: "Book months ahead — sells out!", status: "planned" },
        { id: "td9", title: "Tsukiji Outer Market breakfast", url: "", urlLabel: "", notes: "Go 7–9am for best uni and tamagoyaki.", status: "idea" },
        { id: "td10", title: "Senso-ji, Asakusa", url: "", urlLabel: "", notes: "Very early for photos without crowds.", status: "idea" },
        { id: "td11", title: "Shibuya Sky observation deck", url: "", urlLabel: "", notes: "Book sunset slot in advance.", status: "idea" },
      ],
      days: [
        { id: "day8",  date: "2025-04-04", label: "Travel Day",       reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day9",  date: "2025-04-05", label: "Day 2",            reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day10", date: "2025-04-06", label: "Day 3",            reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
        { id: "day11", date: "2025-04-07", label: "Day 4 / Departure", reflection: "", blocks: { morning: [], afternoon: [], evening: [] } },
      ],
    },
  ],
};

/* ═══════════════════════════════════════════════════════════════
   SHARED UI PRIMITIVES
═══════════════════════════════════════════════════════════════ */
function Btn({ children, onClick, variant = "default", size = "md", disabled, style: sx, title }) {
  const pad = size === "sm" ? "6px 14px" : size === "lg" ? "13px 28px" : size === "xl" ? "16px 36px" : "9px 18px";
  const fs  = size === "sm" ? 13 : size === "lg" ? 16 : size === "xl" ? 17 : 14;
  const vars = {
    default: { background: C.surface3, color: C.text, border: "1px solid transparent" },
    accent:  { background: C.accent,   color: "#0c0e16", border: "1px solid transparent" },
    ghost:   { background: "transparent", color: C.mid, border: `1px solid ${C.border}` },
    danger:  { background: C.warnBg,   color: C.warn,  border: `1px solid ${C.warnBdr}` },
    ok:      { background: C.okBg,     color: C.ok,    border: `1px solid ${C.okBdr}` },
    travel:  { background: C.ok,       color: "#0c0e16", border: "1px solid transparent" },
  };
  return (
    <button title={title} style={{
      display: "inline-flex", alignItems: "center", gap: 6, border: "none",
      borderRadius: 8, fontWeight: 500, padding: pad, fontSize: fs,
      transition: "all 0.15s", opacity: disabled ? 0.45 : 1,
      cursor: disabled ? "not-allowed" : "pointer", ...vars[variant], ...sx,
    }} onClick={onClick} disabled={disabled}>{children}</button>
  );
}

function Tag({ children, color = C.accent, bg }) {
  return (
    <span style={{
      display: "inline-block", padding: "2px 9px", borderRadius: 12, fontSize: 11,
      fontWeight: 600, letterSpacing: "0.03em",
      background: bg || `${color}22`, color,
    }}>{children}</span>
  );
}

function Field({ label, hint, children }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
      {label && <label style={{ fontSize: 12, color: C.mid, fontWeight: 500, letterSpacing: "0.02em" }}>{label}</label>}
      {children}
      {hint && <span style={{ fontSize: 11, color: C.dim }}>{hint}</span>}
    </div>
  );
}

function Input({ label, hint, value, onChange, placeholder, type = "text", style: sx }) {
  return (
    <Field label={label} hint={hint}>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={sx} />
    </Field>
  );
}

function Textarea({ label, hint, value, onChange, placeholder, rows = 3 }) {
  return (
    <Field label={label} hint={hint}>
      <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows} />
    </Field>
  );
}

function Sel({ label, hint, value, onChange, options }) {
  return (
    <Field label={label} hint={hint}>
      <select value={value} onChange={e => onChange(e.target.value)}>
        {options.map(o => {
          const v = typeof o === "string" ? o : o.value;
          const l = typeof o === "string" ? o : o.label;
          return <option key={v} value={v}>{l}</option>;
        })}
      </select>
    </Field>
  );
}

function Modal({ children, onClose, maxWidth = 640 }) {
  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.78)",
      backdropFilter: "blur(8px)", zIndex: 1000,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16,
        width: "100%", maxWidth, maxHeight: "92vh", overflow: "auto",
        boxShadow: "0 32px 100px rgba(0,0,0,0.7)",
        animation: "fadeSlideIn 0.2s ease",
      }}>{children}</div>
    </div>
  );
}

function SectionCard({ children, style: sx }) {
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, ...sx }}>
      {children}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   HOME VIEW
═══════════════════════════════════════════════════════════════ */
function HomeView({ trips, onOpen, onNew, onImportExport, onTemplates }) {
  const mobile = useMobile();
  return (
    <div style={{ maxWidth: 1060, margin: "0 auto", padding: mobile ? "32px 16px 24px" : "56px 28px" }}>

      {/* Header */}
      <div style={{ marginBottom: mobile ? 28 : 52 }}>
        <div style={{ display: "flex", alignItems: mobile ? "flex-start" : "flex-end", justifyContent: "space-between", flexDirection: mobile ? "column" : "row", gap: mobile ? 20 : 0 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <span style={{ fontSize: mobile ? 28 : 36 }}>✈️</span>
              <h1 style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: mobile ? 42 : 58,
                fontWeight: 300, color: C.text, lineHeight: 1, letterSpacing: "-0.01em",
              }}>Journey</h1>
            </div>
            <p style={{ color: C.mid, fontSize: mobile ? 14 : 16, marginLeft: 2 }}>
              {mobile ? "Plan beautifully. Travel confidently." : "Plan beautifully. Travel confidently. Remember everything."}
            </p>
          </div>
          {mobile ? (
            /* Mobile: big primary button + overflow menu */
            <div style={{ display: "flex", gap: 8, width: "100%" }}>
              <Btn variant="accent" size="lg" onClick={onNew} style={{ flex: 1 }}>+ New Trip</Btn>
              <Btn variant="ghost" size="lg" onClick={onTemplates}>📋</Btn>
              <Btn variant="ghost" size="lg" onClick={onImportExport}>⇅</Btn>
            </div>
          ) : (
            <div style={{ display: "flex", gap: 10 }}>
              <Btn variant="ghost" size="lg" onClick={onImportExport}>⇅ Import / Export</Btn>
              <Btn variant="ghost" size="lg" onClick={onTemplates}>📋 Templates</Btn>
              <Btn variant="accent" size="lg" onClick={onNew}>+ New Trip</Btn>
            </div>
          )}
        </div>
      </div>

      {trips.length === 0 ? (
        <div style={{ textAlign: "center", padding: "80px 0", color: C.dim }}>
          <div style={{ fontSize: 52, marginBottom: 16 }}>🗺️</div>
          <p style={{ fontSize: 18, marginBottom: 8 }}>No trips yet.</p>
          <p style={{ fontSize: 14 }}>Create your first trip to get started.</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: mobile ? "1fr" : "repeat(auto-fill, minmax(320px, 1fr))", gap: mobile ? 14 : 20 }}>
          {trips.map((trip) => {
            const sm = STATUS_META[trip.status];
            const totalNights = trip.cities.reduce((s, c) => s + c.nights, 0);
            const allActs = getAllActivities(trip);
            const confCount = allActs.filter(a => a.confirmation).length;
            const isActive = trip.status === "active";
            return (
              <div key={trip.id} onClick={() => onOpen(trip.id)} style={{
                background: C.surface, border: `1px solid ${isActive ? C.okBdr : C.border}`,
                borderRadius: 16, padding: mobile ? "18px 20px" : "24px 26px", cursor: "pointer",
                transition: "all 0.2s", position: "relative",
                boxShadow: isActive ? `0 0 24px rgba(92,184,122,0.12)` : "none",
              }}>
                {isActive && (
                  <div style={{ position: "absolute", top: 14, right: 14, display: "flex", alignItems: "center", gap: 5 }}>
                    <div style={{ width: 7, height: 7, borderRadius: "50%", background: C.ok, animation: "pulse 2s infinite" }} />
                    <span style={{ fontSize: 11, color: C.ok, fontWeight: 600 }}>LIVE</span>
                  </div>
                )}
                <div style={{ display: "flex", gap: 5, marginBottom: 14 }}>
                  {trip.cities.map((c, i) => (
                    <div key={c.id} style={{ flex: c.nights, height: 3, borderRadius: 2, background: CITY_PALETTE[i % CITY_PALETTE.length] }} title={c.name} />
                  ))}
                </div>
                <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 22 : 26, fontWeight: 400, color: C.text, marginBottom: 4, lineHeight: 1.2 }}>{trip.title}</h2>
                <p style={{ color: C.mid, fontSize: 13, marginBottom: 12 }}>{trip.startDate} → {trip.endDate}</p>
                {trip.cities.length > 0 && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
                    {trip.cities.map((c, i) => (
                      <span key={c.id} style={{ fontSize: 12, padding: "3px 10px", borderRadius: 10, background: `${CITY_PALETTE[i % CITY_PALETTE.length]}22`, color: CITY_PALETTE[i % CITY_PALETTE.length], fontWeight: 500 }}>
                        {c.name} · {c.nights}n
                      </span>
                    ))}
                  </div>
                )}
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <Tag color={sm.color}>{sm.label}</Tag>
                  {totalNights > 0 && <span style={{ color: C.dim, fontSize: 13 }}>{totalNights} nights</span>}
                  {trip.ptoDays  && <span style={{ color: C.dim, fontSize: 13 }}>{trip.ptoDays} PTO</span>}
                  {confCount > 0 && <span style={{ color: C.dim, fontSize: 13 }}>{confCount} ✓</span>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TRIP SHELL (tabs, city ribbon, routing)
═══════════════════════════════════════════════════════════════ */
function TripView({ trip, city, cityTab, setCityTab, tripTab, setTripTab, onBack, onSelectCity, onOpenDay, mutateTrip, mutateCity, mutateDay, setModal, templates }) {
  const mobile    = useMobile();
  const cityIdx   = trip.cities.findIndex(c => c.id === city?.id);
  const cityColor = CITY_PALETTE[Math.max(0, cityIdx) % CITY_PALETTE.length];
  const allActs   = getAllActivities(trip);
  const isActive  = trip.status === "active";

  const topTabs = [
    { id: "itinerary", label: "🗓 Itinerary" },
    { id: "prep",      label: `📋 Prep${(trip.prepChecklist||[]).length > 0 ? ` (${(trip.prepChecklist||[]).filter(i=>!i.completed).length})` : ""}` },
    { id: "vault",     label: "🔑 Vault" },
    { id: "budget",    label: "💰 Budget" },
    ...(isActive   ? [{ id: "travel",   label: "🧭 Travel" }] : []),
    ...(trip.status === "complete" ? [{ id: "lookback", label: "📖 Look Back" }] : []),
    { id: "settings",  label: "⚙️ Settings" },
  ];

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Top bar */}
      <div style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: mobile ? "0 14px" : "0 28px" }}>

          {/* Desktop header row */}
          {!mobile && (
            <div style={{ display: "flex", alignItems: "center", gap: 14, paddingTop: 16, paddingBottom: 12, borderBottom: `1px solid ${C.border}` }}>
              <button onClick={onBack} style={{ background: "none", border: "none", color: C.mid, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>← Home</button>
              <span style={{ color: C.dim }}>·</span>
              {isActive && <div style={{ width: 8, height: 8, borderRadius: "50%", background: C.ok, animation: "pulse 2s infinite" }} />}
              <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 400, color: C.text, flex: 1 }}>{trip.title}</h1>
              <span style={{ color: C.dim, fontSize: 13 }}>{trip.startDate} → {trip.endDate}</span>
              {trip.ptoDays && <Tag>{trip.ptoDays} PTO</Tag>}
              <Tag color={STATUS_META[trip.status].color}>{STATUS_META[trip.status].label}</Tag>
              {isActive && <Btn variant="travel" size="sm" onClick={() => setTripTab("travel")}>🧭 Travel Mode</Btn>}
              <Btn variant="ghost" size="sm" onClick={() => setModal({ type: "importExport", trip })}>⇅ Export</Btn>
              <Btn size="sm" onClick={() => setModal({ type: "newCity", tripId: trip.id, cities: trip.cities })}>+ City</Btn>
            </div>
          )}

          {/* Mobile header row — compact */}
          {mobile && (
            <div style={{ display: "flex", alignItems: "center", gap: 10, paddingTop: 12, paddingBottom: 10, borderBottom: `1px solid ${C.border}` }}>
              <button onClick={onBack} style={{ background: "none", border: "none", color: C.mid, fontSize: 22, cursor: "pointer", padding: "0 2px", lineHeight: 1 }}>‹</button>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  {isActive && <div style={{ width: 7, height: 7, borderRadius: "50%", background: C.ok, animation: "pulse 2s infinite", flexShrink: 0 }} />}
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 400, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{trip.title}</h1>
                </div>
                <div style={{ fontSize: 11, color: C.dim, marginTop: 1 }}>
                  {trip.startDate} → {trip.endDate}
                  {trip.ptoDays ? `  ·  ${trip.ptoDays} PTO` : ""}
                </div>
              </div>
              <Tag color={STATUS_META[trip.status].color} style={{ flexShrink: 0 }}>{STATUS_META[trip.status].label}</Tag>
              <Btn size="sm" onClick={() => setModal({ type: "newCity", tripId: trip.id, cities: trip.cities })} style={{ flexShrink: 0 }}>+ City</Btn>
            </div>
          )}

          {/* Tab bar — always scrollable */}
          <div className="tab-bar">
            {topTabs.map(t => (
              <button key={t.id} onClick={() => setTripTab(t.id)} style={{
                background: "none", border: "none",
                padding: mobile ? "10px 14px" : "11px 18px",
                fontSize: mobile ? 13 : 14,
                fontWeight: 500,
                color: tripTab === t.id ? (t.id === "travel" ? C.ok : C.accent) : C.mid,
                cursor: "pointer",
                borderBottom: `2px solid ${tripTab === t.id ? (t.id === "travel" ? C.ok : C.accent) : "transparent"}`,
                transition: "all 0.15s", whiteSpace: "nowrap",
              }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow: "auto" }}>
        {tripTab === "itinerary" && (
          <div style={{ maxWidth: 1280, margin: "0 auto", padding: mobile ? "18px 14px" : "28px" }}>
            <CityRibbon trip={trip} city={city} onSelectCity={onSelectCity} setModal={setModal} />
            {city && (
              <>
                <div className="h-scroll" style={{ marginBottom: 18 }}>
                  <Btn variant={cityTab === "days"     ? "accent" : "ghost"} size="sm" onClick={() => setCityTab("days")}>📅 Days</Btn>
                  <Btn variant={cityTab === "research" ? "accent" : "ghost"} size="sm" onClick={() => setCityTab("research")}>
                    🔍 Research
                    {city.thingsToDo.length > 0 && <span style={{ background: "rgba(255,255,255,0.15)", borderRadius: 8, padding: "0 6px", fontSize: 11, marginLeft: 4 }}>{city.thingsToDo.length}</span>}
                  </Btn>
                </div>
                {cityTab === "days"     && <DaysOverview city={city} cityColor={cityColor} onOpenDay={onOpenDay} onEditCityNotes={notes => mutateCity(city.id, c => ({ ...c, notes }))} />}
                {cityTab === "research" && <ResearchBoard city={city} mutateCity={fn => mutateCity(city.id, fn)} />}
              </>
            )}
          </div>
        )}
        {tripTab === "vault"    && <VaultView    activities={allActs.filter(a => a.confirmation)} currency={trip.currency} />}
        {tripTab === "prep"     && <PrepChecklist trip={trip} mutateTrip={mutateTrip} templates={templates} setModal={setModal} />}
        {tripTab === "budget"   && <BudgetView   activities={allActs} currency={trip.currency} travelers={trip.travelers} />}
        {tripTab === "travel"   && <TravelMode   trip={trip} mutateTrip={mutateTrip} setModal={setModal} />}
        {tripTab === "lookback" && <LookBackView trip={trip} mutateTrip={mutateTrip} />}
        {tripTab === "settings" && <SettingsView trip={trip} mutateTrip={mutateTrip} />}
      </div>
    </div>
  );
}

function CityRibbon({ trip, city, onSelectCity, setModal }) {
  if (trip.cities.length === 0) return (
    <div style={{ textAlign: "center", padding: "60px 0", color: C.dim }}>
      <div style={{ fontSize: 40, marginBottom: 12 }}>🏙️</div>
      <p style={{ marginBottom: 16 }}>Add your first city to start building your itinerary</p>
      <Btn variant="accent" onClick={() => setModal({ type: "newCity", tripId: trip.id, cities: [] })}>+ Add City</Btn>
    </div>
  );
  return (
    <div style={{ display: "flex", gap: 10, marginBottom: 28, overflowX: "auto", paddingBottom: 4 }}>
      {trip.cities.map((c, i) => {
        const col    = CITY_PALETTE[i % CITY_PALETTE.length];
        const active = c.id === city?.id;
        return (
          <button key={c.id} onClick={() => onSelectCity(c.id)} style={{
            background: active ? `${col}22` : C.surface,
            border: `1px solid ${active ? col : C.border}`,
            borderRadius: 12, padding: "10px 22px", color: active ? col : C.mid,
            cursor: "pointer", fontWeight: 500, whiteSpace: "nowrap",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 2, transition: "all 0.15s",
          }}>
            <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18 }}>{c.name}</span>
            <span style={{ fontSize: 11, opacity: 0.75 }}>{c.nights} nights</span>
          </button>
        );
      })}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TRAVEL MODE
═══════════════════════════════════════════════════════════════ */
function TravelMode({ trip, mutateTrip, setModal }) {
  const mobile = useMobile();
  const [travelTab, setTravelTab] = useState("today");
  const [quickAdd,  setQuickAdd]  = useState(false);
  const allActs  = getAllActivities(trip);
  const todayActs = getTodayActivities(trip);
  const { current, next } = getCurrentActivity(todayActs);
  const t = today();

  const todayCity = trip.cities.find(c => c.days.some(d => d.date === t));
  const todayDay  = todayCity?.days.find(d => d.date === t);

  const markComplete = (act) => {
    mutateTrip(tr => ({
      ...tr,
      cities: tr.cities.map(c => ({
        ...c,
        days: c.days.map(d => ({
          ...d,
          blocks: Object.fromEntries(
            Object.entries(d.blocks).map(([bl, acts]) => [
              bl, acts.map(a => a.id === act.id ? { ...a, completed: !a.completed } : a),
            ])
          ),
        })),
      })),
    }));
  };

  const addQuick = ({ title, block, cityId, dayId, time, type, cost, notes }) => {
    const act = newActivity({ title, time, type, notes, addedOnTrip: true, cost: { ...newActivity().cost, estimated: cost } });
    mutateTrip(tr => ({
      ...tr,
      cities: tr.cities.map(c => c.id === cityId ? {
        ...c,
        days: c.days.map(d => d.id === dayId ? {
          ...d,
          blocks: { ...d.blocks, [block]: [...d.blocks[block], act] },
        } : d),
      } : c),
    }));
  };

  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: mobile ? "16px 14px" : "24px 28px", position: "relative" }}>
      {/* Now / Next Banner */}
      <div style={{
        background: `linear-gradient(135deg, rgba(92,184,122,0.15) 0%, rgba(78,205,196,0.08) 100%)`,
        border: `1px solid ${C.okBdr}`, borderRadius: 16, padding: mobile ? "16px" : "20px 24px", marginBottom: 24,
        animation: "fadeSlideIn 0.3s ease",
      }}>
        <div style={{ display: "flex", gap: mobile ? 0 : 24, flexDirection: mobile ? "column" : "row" }}>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontSize: 11, color: C.ok, fontWeight: 700, letterSpacing: "0.08em", marginBottom: 8, textTransform: "uppercase" }}>▶ Now</div>
            {current ? (
              <>
                <div style={{ fontSize: 18, fontWeight: 600, color: C.text, marginBottom: 4 }}>
                  {ACT_TYPES.find(t => t.id === current.type)?.icon} {current.title}
                </div>
                <div style={{ fontSize: 13, color: C.mid }}>
                  {current.time && `${current.time} · `}{current.location || current.cityName}
                </div>
                {current.confirmation && (
                  <div style={{ marginTop: 8, display: "inline-flex", alignItems: "center", gap: 6, background: C.okBg, borderRadius: 8, padding: "4px 12px" }}>
                    <span style={{ fontSize: 11, color: C.mid }}>Confirmation:</span>
                    <span style={{ fontFamily: "monospace", fontSize: 15, color: C.ok, fontWeight: 700 }}>{current.confirmation}</span>
                  </div>
                )}
                {current.transitSteps && (
                  <div style={{ marginTop: 10, background: C.surface3, borderRadius: 8, padding: "10px 14px", fontSize: 13, color: C.mid, whiteSpace: "pre-line", lineHeight: 1.7 }}>
                    {current.transitSteps}
                  </div>
                )}
              </>
            ) : (
              <div style={{ color: C.dim, fontSize: 14, fontStyle: "italic" }}>
                {todayActs.length === 0 ? "No activities scheduled for today." : "No current activity — enjoy the moment! ☀️"}
              </div>
            )}
          </div>
          <div style={{ flex: 1, minWidth: 200, borderLeft: mobile ? "none" : `1px solid ${C.border}`, borderTop: mobile ? `1px solid ${C.border}` : "none", paddingLeft: mobile ? 0 : 24, paddingTop: mobile ? 16 : 0, marginTop: mobile ? 16 : 0 }}>
            <div style={{ fontSize: 11, color: C.teal, fontWeight: 700, letterSpacing: "0.08em", marginBottom: 8, textTransform: "uppercase" }}>⏭ Next</div>
            {next ? (
              <>
                <div style={{ fontSize: 18, fontWeight: 600, color: C.text, marginBottom: 4 }}>
                  {ACT_TYPES.find(t => t.id === next.type)?.icon} {next.title}
                </div>
                <div style={{ fontSize: 13, color: C.mid }}>
                  {next.time && `${next.time} · `}{next.location || next.cityName}
                </div>
                {next.confirmation && (
                  <div style={{ marginTop: 8, display: "inline-flex", alignItems: "center", gap: 6, background: C.tealBg, borderRadius: 8, padding: "4px 12px" }}>
                    <span style={{ fontSize: 11, color: C.mid }}>Confirmation:</span>
                    <span style={{ fontFamily: "monospace", fontSize: 15, color: C.teal, fontWeight: 700 }}>{next.confirmation}</span>
                  </div>
                )}
              </>
            ) : (
              <div style={{ color: C.dim, fontSize: 14, fontStyle: "italic" }}>Nothing more scheduled today.</div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        <Btn variant={travelTab === "today" ? "ok" : "ghost"} size="sm" onClick={() => setTravelTab("today")}>📅 Today</Btn>
        <Btn variant={travelTab === "full"  ? "ok" : "ghost"} size="sm" onClick={() => setTravelTab("full")}>🗓 Full Trip</Btn>
        <div style={{ flex: 1 }} />
        <Btn variant="travel" size="sm" onClick={() => setQuickAdd(true)}>⚡ Quick Add</Btn>
      </div>

      {/* Today timeline */}
      {travelTab === "today" && (
        <div>
          {todayCity && todayDay ? (
            <>
              <div style={{ marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, color: C.text }}>{todayCity.name} · {todayDay.label}</span>
                <Tag color={C.ok}>{t}</Tag>
              </div>
              {BLOCKS.map(bl => {
                const acts = todayDay.blocks[bl];
                if (acts.length === 0) return null;
                const m = BLOCK_META[bl];
                return (
                  <div key={bl} style={{ marginBottom: 20 }}>
                    <div style={{ fontSize: 13, color: m.accent, fontWeight: 600, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                      {m.icon} {m.label}
                    </div>
                    {acts.map(act => (
                      <TravelActivityRow key={act.id} activity={act} onToggle={() => markComplete(act)} />
                    ))}
                  </div>
                );
              })}
              {todayActs.length === 0 && (
                <div style={{ textAlign: "center", padding: "40px 0", color: C.dim }}>
                  <p>No activities planned for today yet.</p>
                  <p style={{ marginTop: 6 }}>Use ⚡ Quick Add to capture what you're up to!</p>
                </div>
              )}
            </>
          ) : (
            <div style={{ textAlign: "center", padding: "48px 0", color: C.dim }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>📍</div>
              <p>Today ({t}) doesn't match any day in your itinerary.</p>
              <p style={{ marginTop: 6, fontSize: 13 }}>You can still use Quick Add to log activities.</p>
            </div>
          )}
        </div>
      )}

      {/* Full trip timeline */}
      {travelTab === "full" && (
        <div>
          {trip.cities.map((c, ci) => (
            <div key={c.id} style={{ marginBottom: 32 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                <div style={{ width: 12, height: 12, borderRadius: "50%", background: CITY_PALETTE[ci % CITY_PALETTE.length], flexShrink: 0 }} />
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 24, color: C.text }}>{c.name}</h3>
                <Tag color={CITY_PALETTE[ci % CITY_PALETTE.length]}>{c.nights} nights</Tag>
              </div>
              {c.days.map(d => {
                const isToday = d.date === t;
                const allBlkActs = BLOCKS.flatMap(b => d.blocks[b].map(a => ({...a, block: b})));
                if (allBlkActs.length === 0 && !isToday) return null;
                return (
                  <div key={d.id} style={{ marginBottom: 12, paddingLeft: 24, borderLeft: `2px solid ${isToday ? C.ok : C.dim}` }}>
                    <div style={{ marginBottom: 8, display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 14, fontWeight: 600, color: isToday ? C.ok : C.text }}>{d.label}</span>
                      <span style={{ fontSize: 12, color: C.dim }}>{d.date}</span>
                      {isToday && <Tag color={C.ok}>Today</Tag>}
                    </div>
                    {allBlkActs.map(act => (
                      <TravelActivityRow key={act.id} activity={act} compact onToggle={() => markComplete(act)} />
                    ))}
                    {allBlkActs.length === 0 && <div style={{ fontSize: 13, color: C.dim, fontStyle: "italic", paddingBottom: 4 }}>No activities yet</div>}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}

      {/* Quick Add Sheet */}
      {quickAdd && (
        <Modal onClose={() => setQuickAdd(false)} maxWidth={480}>
          <QuickAddSheet trip={trip} onAdd={data => { addQuick(data); setQuickAdd(false); }} onClose={() => setQuickAdd(false)} />
        </Modal>
      )}
    </div>
  );
}

function TravelActivityRow({ activity, onToggle, compact }) {
  const t = ACT_TYPES.find(x => x.id === activity.type) || ACT_TYPES[7];
  const [open, setOpen] = useState(false);
  return (
    <div style={{
      background: activity.completed ? "transparent" : C.surface2,
      border: `1px solid ${activity.completed ? C.dim : C.border}`,
      borderRadius: 10, padding: compact ? "8px 12px" : "12px 16px",
      marginBottom: 8, opacity: activity.completed ? 0.55 : 1, transition: "all 0.15s",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <input type="checkbox" checked={!!activity.completed} onChange={onToggle} style={{ flexShrink: 0 }} />
        <span style={{ fontSize: compact ? 15 : 17 }}>{t.icon}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <span style={{
            fontSize: compact ? 13 : 15, fontWeight: 500, color: C.text,
            textDecoration: activity.completed ? "line-through" : "none",
          }}>{activity.title || "Untitled"}</span>
          {activity.time && <span style={{ fontSize: 12, color: C.dim, marginLeft: 8 }}>{activity.time}</span>}
          {activity.addedOnTrip && <Tag color={C.purple} style={{ marginLeft: 6 }}>on trip</Tag>}
        </div>
        {(activity.confirmation || activity.transitSteps || activity.notes) && (
          <button onClick={() => setOpen(o => !o)} style={{ background: "none", border: "none", color: C.dim, fontSize: 12, padding: "2px 4px" }}>
            {open ? "▲" : "▼"}
          </button>
        )}
      </div>
      {open && (
        <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${C.border}`, display: "flex", flexDirection: "column", gap: 8 }}>
          {activity.confirmation && (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 12, color: C.mid }}>Confirmation:</span>
              <span style={{ fontFamily: "monospace", fontSize: 16, color: C.ok, fontWeight: 700 }}>{activity.confirmation}</span>
            </div>
          )}
          {activity.location && <div style={{ fontSize: 13, color: C.mid }}>📍 {activity.location}</div>}
          {activity.transitSteps && (
            <div style={{ background: C.surface3, borderRadius: 8, padding: "10px 14px", fontSize: 13, color: C.mid, whiteSpace: "pre-line", lineHeight: 1.7 }}>
              {activity.transitSteps}
            </div>
          )}
          {activity.notes && <div style={{ fontSize: 13, color: C.mid, lineHeight: 1.6 }}>{activity.notes}</div>}
        </div>
      )}
    </div>
  );
}

function QuickAddSheet({ trip, onAdd, onClose }) {
  const t = today();
  const defaultCity = trip.cities.find(c => c.days.some(d => d.date === t)) || trip.cities[0];
  const [cityId, setCityId_] = useState(defaultCity?.id || "");
  const activeCity = trip.cities.find(c => c.id === cityId);
  const defaultDay = activeCity?.days.find(d => d.date === t) || activeCity?.days[0];
  const [dayId,  setDayId_]  = useState(defaultDay?.id || "");
  const [block,  setBlock_]  = useState(() => {
    const h = new Date().getHours();
    return h < 12 ? "morning" : h < 17 ? "afternoon" : "evening";
  });
  const [title, setTitle]   = useState("");
  const [type,  setType]    = useState("other");
  const [time,  setTime]    = useState("");
  const [cost,  setCost]    = useState("");
  const [notes, setNotes]   = useState("");

  const days = activeCity?.days || [];

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, color: C.text }}>⚡ Quick Add</h3>
          <p style={{ color: C.mid, fontSize: 13, marginTop: 3 }}>Capture it fast — details can wait.</p>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
      </div>
      <div style={{ display: "grid", gap: 14 }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 12 }}>
          <Input label="What?" value={title} onChange={setTitle} placeholder="e.g., Stumbled into amazing ramen spot..." />
          <Sel label="Type" value={type} onChange={setType} options={ACT_TYPES.map(t => ({ value: t.id, label: `${t.icon} ${t.label}` }))} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
          <Sel label="City" value={cityId} onChange={v => { setCityId_(v); const c = trip.cities.find(x => x.id === v); setDayId_(c?.days[0]?.id || ""); }} options={trip.cities.map(c => ({ value: c.id, label: c.name }))} />
          <Sel label="Day"   value={dayId}  onChange={setDayId_}  options={days.map(d => ({ value: d.id, label: `${d.label} (${d.date})` }))} />
          <Sel label="Block" value={block}  onChange={setBlock_}  options={BLOCKS.map(b => ({ value: b, label: `${BLOCK_META[b].icon} ${BLOCK_META[b].label}` }))} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Input label="Time (optional)" value={time} onChange={setTime} placeholder="14:30" />
          <Input label={`Cost (${trip.currency}, optional)`} value={cost} onChange={setCost} placeholder="0.00" type="number" />
        </div>
        <Input label="Notes (optional)" value={notes} onChange={setNotes} placeholder="Any quick notes..." />
        <div style={{ background: C.purpleBg, borderRadius: 8, padding: "8px 12px", fontSize: 12, color: C.purple, border: `1px solid ${C.purpleBdr}` }}>
          🏷️ This will be tagged "added on trip" — visible in your Look Back view.
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <Btn variant="ghost"  onClick={onClose}>Cancel</Btn>
          <Btn variant="travel" disabled={!title.trim() || !cityId || !dayId} onClick={() => onAdd({ title, type, block, cityId, dayId, time, cost, notes })}>
            Add to Trip
          </Btn>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   LOOK BACK VIEW
═══════════════════════════════════════════════════════════════ */
function LookBackView({ trip, mutateTrip }) {
  const mobile = useMobile();
  const [copied, setCopied] = useState(false);
  const allActs = getAllActivities(trip);
  const actTotal = allActs.length;
  const onTrip   = allActs.filter(a => a.addedOnTrip).length;
  const confTotal = allActs.filter(a => a.confirmation).length;

  const allCosts = allActs.reduce((s, a) => s + parseFloat(a.cost.confirmed || a.cost.estimated || 0), 0);

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href + "?share=" + trip.id).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: mobile ? "24px 16px" : "36px 28px" }}>
      {/* Header */}
      <div style={{ marginBottom: mobile ? 20 : 32, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 28 : 40, fontWeight: 300, color: C.text, lineHeight: 1.1 }}>
            📖 {trip.title}
          </h2>
          <p style={{ color: C.mid, fontSize: mobile ? 13 : 15, marginTop: 6 }}>{trip.startDate} → {trip.endDate}</p>
          <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
            <Tag color={C.ok}>{trip.ptoDays || "?"} PTO</Tag>
            <Tag>{trip.cities.reduce((s, c) => s + c.nights, 0)} nights</Tag>
            <Tag color={C.purple}>{onTrip} spontaneous</Tag>
            <Tag color={C.teal}>{confTotal} reservations</Tag>
          </div>
        </div>
        <Btn variant="ghost" size="sm" onClick={copyLink}>{copied ? "✓" : "🔗"}</Btn>
      </div>

      {/* Trip-level reflection */}
      <SectionCard style={{ padding: "20px 24px", marginBottom: 28 }}>
        <Textarea
          label="✍️ Trip reflection — overall thoughts, memories, what to remember next time"
          value={trip.tripNotes || ""}
          onChange={v => mutateTrip(t => ({ ...t, tripNotes: v }))}
          placeholder="Best moments, surprises, what worked, what you'd do differently, restaurants to revisit..."
          rows={4}
        />
      </SectionCard>

      {/* Stats row */}
      <div style={{ display: "grid", gridTemplateColumns: mobile ? "1fr 1fr" : "repeat(4, 1fr)", gap: 12, marginBottom: 28 }}>
        {[
          { icon: "🏙️", val: trip.cities.length,   label: "Cities" },
          { icon: "📅", val: trip.cities.reduce((s,c)=>s+c.nights,0), label: "Nights" },
          { icon: "📌", val: actTotal,              label: "Activities" },
          { icon: "💰", val: fmt(allCosts, trip.currency), label: "Total spent" },
        ].map(s => (
          <div key={s.label} style={{ background: C.surface, borderRadius: 12, padding: "16px 14px", textAlign: "center", border: `1px solid ${C.border}` }}>
            <div style={{ fontSize: 22, marginBottom: 6 }}>{s.icon}</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: C.text, fontFamily: "'Cormorant Garamond', serif" }}>{s.val}</div>
            <div style={{ fontSize: 12, color: C.mid, marginTop: 3 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Memoir timeline */}
      {trip.cities.map((c, ci) => {
        const col = CITY_PALETTE[ci % CITY_PALETTE.length];
        return (
          <div key={c.id} style={{ marginBottom: 40 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, paddingBottom: 12, borderBottom: `2px solid ${col}44` }}>
              <div style={{ width: 14, height: 14, borderRadius: "50%", background: col }} />
              <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: C.text, fontWeight: 300 }}>{c.name}</h3>
              <span style={{ color: C.dim, fontSize: 14 }}>{c.nights} nights</span>
            </div>
            {c.days.map(d => {
              const allDayActs = BLOCKS.flatMap(bl => d.blocks[bl].map(a => ({ ...a, block: bl })));
              return (
                <div key={d.id} style={{ marginBottom: 24, paddingLeft: 22, borderLeft: `2px solid ${C.surface3}` }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                    <h4 style={{ fontSize: 16, fontWeight: 600, color: C.text }}>{d.label}</h4>
                    <span style={{ fontSize: 12, color: C.dim }}>{d.date}</span>
                  </div>
                  {/* Activities */}
                  {allDayActs.length > 0 && (
                    <div style={{ marginBottom: 12 }}>
                      {allDayActs.map(act => {
                        const ti = ACT_TYPES.find(x => x.id === act.type) || ACT_TYPES[7];
                        return (
                          <div key={act.id} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                            <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}>{ti.icon}</span>
                            <div style={{ flex: 1 }}>
                              <span style={{ fontSize: 14, color: act.completed ? C.mid : C.text, textDecoration: act.completed ? "line-through" : "none" }}>
                                {act.title || "Untitled"}
                              </span>
                              {act.time && <span style={{ fontSize: 12, color: C.dim, marginLeft: 8 }}>{act.time}</span>}
                              {act.addedOnTrip && <Tag color={C.purple} style={{ marginLeft: 6 }}>spontaneous</Tag>}
                              {act.notes && <div style={{ fontSize: 12, color: C.mid, marginTop: 2, fontStyle: "italic" }}>{act.notes}</div>}
                            </div>
                            {(act.cost.confirmed || act.cost.estimated) && (
                              <span style={{ fontSize: 12, color: C.dim, flexShrink: 0 }}>
                                {fmt(parseFloat(act.cost.confirmed || act.cost.estimated), trip.currency)}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  {/* Day reflection */}
                  <div>
                    <textarea
                      value={d.reflection || ""}
                      onChange={e => mutateTrip(tr => ({
                        ...tr,
                        cities: tr.cities.map(cc => cc.id === c.id ? {
                          ...cc,
                          days: cc.days.map(dd => dd.id === d.id ? { ...dd, reflection: e.target.value } : dd),
                        } : cc),
                      }))}
                      placeholder={`How was ${d.label}? Any highlights to remember?`}
                      rows={2}
                      style={{ fontSize: 13, fontStyle: "italic", background: C.surface2, color: C.mid }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        );
      })}

      {/* Footer share note */}
      <SectionCard style={{ padding: "16px 20px", marginTop: 8, background: C.accentBg, border: `1px solid ${C.accentBdr}` }}>
        <p style={{ fontSize: 13, color: C.mid, lineHeight: 1.7 }}>
          <strong style={{ color: C.accent }}>💡 Sharing:</strong> The "Share Link" above copies a link to this view. In a future update, this will generate a true read-only page your travel partner (or anyone) can browse without needing an account — including the full timeline, reflections, and a PDF export option.
        </p>
      </SectionCard>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SETTINGS VIEW
═══════════════════════════════════════════════════════════════ */
function SettingsView({ trip, mutateTrip }) {
  const mobile = useMobile();
  const [form, setForm] = useState({
    title:     trip.title,
    startDate: trip.startDate,
    endDate:   trip.endDate,
    currency:  trip.currency,
    ptoDays:   trip.ptoDays || "",
    status:    trip.status,
    travelers: trip.travelers.join(", "),
  });
  const [saved, setSaved] = useState(false);
  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const autoPTO = getPTODays(form.startDate, form.endDate);

  const save = () => {
    mutateTrip(t => ({
      ...t,
      title:     form.title.trim() || t.title,
      startDate: form.startDate,
      endDate:   form.endDate,
      currency:  form.currency.toUpperCase() || t.currency,
      ptoDays:   form.ptoDays,
      status:    form.status,
      travelers: form.travelers.split(",").map(s => s.trim()).filter(Boolean),
    }));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const statusFlow = [
    { id: "planning", label: "Planning", icon: "🗓", desc: "Building the itinerary" },
    { id: "active",   label: "On Trip",  icon: "✈️", desc: "Travel Mode unlocked" },
    { id: "complete", label: "Complete", icon: "✅", desc: "Look Back view unlocked" },
  ];

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: mobile ? "20px 14px" : "36px 28px" }}>
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 26 : 32, color: C.text, marginBottom: mobile ? 20 : 28 }}>⚙️ Trip Settings</h2>

      {/* Trip status */}
      <SectionCard style={{ padding: "20px 22px", marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 16 }}>Trip Status</h3>
        <div style={{ display: "flex", gap: mobile ? 8 : 12, flexDirection: mobile ? "column" : "row" }}>
          {statusFlow.map(s => {
            const active = form.status === s.id;
            const col = STATUS_META[s.id].color;
            return (
              <button key={s.id} onClick={() => upd("status", s.id)} style={{
                flex: 1, padding: mobile ? "10px 12px" : "14px 12px", borderRadius: 12, cursor: "pointer",
                background: active ? `${col}22` : C.surface2,
                border: `1px solid ${active ? col : C.border}`,
                display: "flex", flexDirection: mobile ? "row" : "column",
                alignItems: "center", gap: mobile ? 10 : 6, transition: "all 0.15s",
              }}>
                <span style={{ fontSize: 22 }}>{s.icon}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: active ? col : C.mid }}>{s.label}</span>
                <span style={{ fontSize: 11, color: C.dim }}>{s.desc}</span>
              </button>
            );
          })}
        </div>
      </SectionCard>

      {/* Core info */}
      <SectionCard style={{ padding: "20px 22px", marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 16 }}>Trip Info</h3>
        <div style={{ display: "grid", gap: 14 }}>
          <Input label="Trip title" value={form.title} onChange={v => upd("title", v)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <Input label="Start date" type="date" value={form.startDate} onChange={v => upd("startDate", v)} />
            <Input label="End date"   type="date" value={form.endDate}   onChange={v => upd("endDate", v)}   />
          </div>
          <Input label="Currency code" value={form.currency} onChange={v => upd("currency", v)} placeholder="USD" />
          <div style={{ background: C.accentBg, borderRadius: 8, padding: "10px 14px", border: `1px solid ${C.accentBdr}`, fontSize: 12, color: C.mid }}>
            <strong style={{ color: C.accent }}>💡 Multi-currency:</strong> Future update will let you set a base currency here and record costs in local currencies (JPY, EUR, etc.) with conversion rates stored per trip.
          </div>
        </div>
      </SectionCard>

      {/* PTO Calculator */}
      <SectionCard style={{ padding: "20px 22px", marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 6 }}>PTO Calculator</h3>
        <p style={{ fontSize: 13, color: C.mid, marginBottom: 14 }}>Weekdays in your trip date range (excludes Sat/Sun). Override if your company counts differently.</p>
        <div style={{ display: "flex", gap: 14, alignItems: "flex-end" }}>
          <div style={{ flex: 1 }}>
            <Input label="PTO days used" type="number" value={form.ptoDays} onChange={v => upd("ptoDays", v)} placeholder="Override..." />
          </div>
          {form.startDate && form.endDate && (
            <div style={{ flexShrink: 0, paddingBottom: 2 }}>
              <div style={{ fontSize: 12, color: C.dim, marginBottom: 6 }}>Auto-calculated</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 20, fontWeight: 700, color: C.accent, fontFamily: "'Cormorant Garamond', serif" }}>{autoPTO}</span>
                <span style={{ fontSize: 13, color: C.mid }}>weekdays</span>
                <Btn size="sm" variant="ghost" onClick={() => upd("ptoDays", autoPTO)}>Use this</Btn>
              </div>
            </div>
          )}
        </div>
      </SectionCard>

      {/* Travelers */}
      <SectionCard style={{ padding: "20px 22px", marginBottom: 28 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 8 }}>Travelers</h3>
        <Input label="Names (comma-separated)" value={form.travelers} onChange={v => upd("travelers", v)} placeholder="You, Partner" />
        <p style={{ fontSize: 12, color: C.dim, marginTop: 8 }}>Used in the Budget bill-split view.</p>
      </SectionCard>

      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <Btn variant="accent" size="lg" onClick={save}>Save Settings</Btn>
        {saved && <span style={{ color: C.ok, fontSize: 14 }}>✓ Saved!</span>}
      </div>

      {/* Export shortcuts */}
      <div style={{ marginTop: 32, paddingTop: 28, borderTop: `1px solid ${C.border}` }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 14 }}>Export This Trip</h3>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <Btn variant="ghost" onClick={() => exportTripJSON(trip)}>💾 JSON Backup</Btn>
          <Btn variant="ghost" onClick={() => exportBudgetCSV(trip)}>📊 Budget CSV</Btn>
          <Btn variant="ghost" onClick={() => exportItineraryMD(trip)}>📄 Itinerary Markdown</Btn>
        </div>
        <p style={{ fontSize: 12, color: C.dim, marginTop: 10 }}>JSON backups can be re-imported. CSV and Markdown are export-only.</p>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   DAYS OVERVIEW
═══════════════════════════════════════════════════════════════ */
function DaysOverview({ city, cityColor, onOpenDay, onEditCityNotes }) {
  const [editNotes, setEditNotes] = useState(false);
  const [noteDraft, setNoteDraft] = useState(city.notes);
  return (
    <div>
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 18px", marginBottom: 18 }}>
        {!editNotes ? (
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <span style={{ fontSize: 14, color: C.mid, flexShrink: 0 }}>📝 City notes:</span>
            <span style={{ color: city.notes ? C.text : C.dim, fontSize: 14, fontStyle: city.notes ? "normal" : "italic", flex: 1 }}>
              {city.notes || "No notes yet — add logistics, tips, reminders..."}
            </span>
            <button onClick={() => { setNoteDraft(city.notes); setEditNotes(true); }} style={{ background: "none", border: "none", color: C.dim, fontSize: 12, cursor: "pointer" }}>Edit</button>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <textarea value={noteDraft} onChange={e => setNoteDraft(e.target.value)} rows={3} placeholder="City logistics, tips, notes..." />
            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="accent" size="sm" onClick={() => { onEditCityNotes(noteDraft); setEditNotes(false); }}>Save</Btn>
              <Btn variant="ghost"  size="sm" onClick={() => setEditNotes(false)}>Cancel</Btn>
            </div>
          </div>
        )}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {city.days.map(day => {
          const totalActs = BLOCKS.reduce((s, b) => s + day.blocks[b].length, 0);
          const isToday   = day.date === today();
          return (
            <div key={day.id} onClick={() => onOpenDay(day.id)} style={{
              background: isToday ? "rgba(92,184,122,0.05)" : C.surface,
              border: `1px solid ${isToday ? C.okBdr : C.border}`,
              borderRadius: 12, padding: "16px 20px", cursor: "pointer",
              transition: "all 0.15s", display: "flex", alignItems: "stretch", gap: 18,
            }}
            onMouseEnter={e => { e.currentTarget.style.background = C.surface2; e.currentTarget.style.borderColor = `${cityColor}55`; }}
            onMouseLeave={e => { e.currentTarget.style.background = isToday ? "rgba(92,184,122,0.05)" : C.surface; e.currentTarget.style.borderColor = isToday ? C.okBdr : C.border; }}
            >
              <div style={{ width: 3, background: isToday ? C.ok : cityColor, borderRadius: 2, flexShrink: 0 }} />
              <div style={{ minWidth: 140 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, color: C.text }}>{day.label}</div>
                  {isToday && <Tag color={C.ok}>Today</Tag>}
                </div>
                <div style={{ color: C.dim, fontSize: 12, marginTop: 2 }}>{day.date}</div>
              </div>
              <div style={{ flex: 1, display: "flex", gap: 20 }}>
                {BLOCKS.map(b => {
                  const acts = day.blocks[b];
                  const m    = BLOCK_META[b];
                  return (
                    <div key={b} style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 11, color: C.dim, marginBottom: 5, display: "flex", gap: 4, alignItems: "center" }}>
                        {m.icon} {m.label}
                      </div>
                      {acts.length === 0
                        ? <span style={{ fontSize: 12, color: C.dim, fontStyle: "italic" }}>Empty</span>
                        : acts.slice(0, 3).map(a => {
                            const ti = ACT_TYPES.find(x => x.id === a.type);
                            return (
                              <div key={a.id} style={{ fontSize: 13, color: C.text, display: "flex", alignItems: "center", gap: 5, marginBottom: 3, overflow: "hidden" }}>
                                <span>{ti?.icon}</span>
                                <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>{a.title || "Untitled"}</span>
                                {a.confirmation && <span style={{ color: C.ok, fontSize: 10 }}>✓</span>}
                                {a.addedOnTrip  && <span style={{ color: C.purple, fontSize: 10 }}>★</span>}
                              </div>
                            );
                          })
                      }
                      {acts.length > 3 && <div style={{ fontSize: 11, color: C.dim }}>+{acts.length - 3} more</div>}
                    </div>
                  );
                })}
              </div>
              <div style={{ color: C.dim, fontSize: 13, alignSelf: "center", flexShrink: 0 }}>
                {totalActs} {totalActs === 1 ? "activity" : "activities"} →
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   RESEARCH BOARD
═══════════════════════════════════════════════════════════════ */
function ResearchBoard({ city, mutateCity }) {
  const mobile  = useMobile();
  const [adding, setAdding]   = useState(false);
  const [draft,  setDraft]    = useState({ title: "", url: "", urlLabel: "", notes: "", status: "idea" });
  const upd = (k, v) => setDraft(d => ({ ...d, [k]: v }));

  const save = () => {
    if (!draft.title.trim()) return;
    mutateCity(c => ({ ...c, thingsToDo: [...c.thingsToDo, newTodo(draft)] }));
    setDraft({ title: "", url: "", urlLabel: "", notes: "", status: "idea" });
    setAdding(false);
  };
  const updateTodo = (id, upds) => mutateCity(c => ({ ...c, thingsToDo: c.thingsToDo.map(t => t.id === id ? { ...t, ...upds } : t) }));
  const deleteTodo = (id)       => mutateCity(c => ({ ...c, thingsToDo: c.thingsToDo.filter(t => t.id !== id) }));

  const cols = {
    idea:    { label: "💡 Ideas",   color: C.accent },
    planned: { label: "📅 Planned", color: C.ok },
    done:    { label: "✅ Done",    color: C.mid },
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
        <div>
          <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, color: C.text }}>Research Board</h3>
          <p style={{ color: C.mid, fontSize: 13, marginTop: 3 }}>Ideas, links, and notes for {city.name}</p>
        </div>
        <Btn variant="accent" size="sm" onClick={() => setAdding(true)}>+ Add Idea</Btn>
      </div>

      {adding && (
        <div style={{ background: C.surface2, borderRadius: 12, padding: 20, marginBottom: 24, border: `1px solid ${C.accentBdr}` }}>
          <h4 style={{ color: C.text, fontSize: 15, marginBottom: 14 }}>New Research Item</h4>
          <div style={{ display: "grid", gap: 12 }}>
            <Input label="Title / What is it?" value={draft.title} onChange={v => upd("title", v)} placeholder="e.g., Fushimi Inari at sunrise" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label="URL" value={draft.url} onChange={v => upd("url", v)} placeholder="https://..." />
              <Input label="Link label" value={draft.urlLabel} onChange={v => upd("urlLabel", v)} placeholder='e.g., "Book tickets"' />
            </div>
            <Textarea label="Notes" value={draft.notes} onChange={v => upd("notes", v)} placeholder="Research notes, tips, warnings..." rows={2} />
            <Sel label="Status" value={draft.status} onChange={v => upd("status", v)} options={[{value:"idea",label:"💡 Idea"},{value:"planned",label:"📅 Planned"},{value:"done",label:"✅ Done"}]} />
            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="accent" onClick={save}>Save</Btn>
              <Btn variant="ghost"  onClick={() => setAdding(false)}>Cancel</Btn>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: mobile ? "1fr" : "repeat(3, 1fr)", gap: mobile ? 24 : 20 }}>
        {Object.entries(cols).map(([status, meta]) => {
          const items = city.thingsToDo.filter(t => t.status === status);
          return (
            <div key={status}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <span style={{ fontSize: 14, fontWeight: 600, color: meta.color }}>{meta.label}</span>
                <span style={{ background: C.surface3, borderRadius: "50%", width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: C.mid }}>{items.length}</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {items.map(todo => <TodoCard key={todo.id} todo={todo} onUpdate={u => updateTodo(todo.id, u)} onDelete={() => deleteTodo(todo.id)} />)}
                {items.length === 0 && <div style={{ color: C.dim, fontSize: 13, fontStyle: "italic", padding: "6px 0" }}>None yet</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TodoCard({ todo, onUpdate, onDelete }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ background: C.surface2, borderRadius: 10, padding: "12px 14px", border: `1px solid ${C.border}` }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, color: C.text, fontWeight: 500, marginBottom: 3 }}>{todo.title}</div>
          {!open && todo.notes && <div style={{ fontSize: 12, color: C.mid, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{todo.notes}</div>}
          {!open && todo.url && <a href={todo.url} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} style={{ fontSize: 12, display: "block" }}>🔗 {todo.urlLabel || todo.url}</a>}
          {open && (
            <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 10 }}>
              {todo.notes && <div style={{ fontSize: 13, color: C.mid, lineHeight: 1.6 }}>{todo.notes}</div>}
              {todo.url   && <a href={todo.url} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}>🔗 {todo.urlLabel || todo.url}</a>}
              <Sel value={todo.status} onChange={v => onUpdate({ status: v })} options={[{value:"idea",label:"💡 Idea"},{value:"planned",label:"📅 Planned"},{value:"done",label:"✅ Done"}]} />
            </div>
          )}
        </div>
        <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
          <button onClick={() => setOpen(o => !o)} style={{ background: "none", border: "none", color: C.dim, cursor: "pointer", fontSize: 12, padding: "2px 4px" }}>{open ? "▲" : "▼"}</button>
          <button onClick={onDelete}               style={{ background: "none", border: "none", color: C.warn, cursor: "pointer", fontSize: 13, padding: "2px 4px" }}>✕</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   DAY VIEW
═══════════════════════════════════════════════════════════════ */
function DayView({ trip, city, day, onBack, addActivity, updateActivity, deleteActivity, mutateDay }) {
  const [actModal, setActModal] = useState(null);
  const [mobileBlock, setMobileBlock] = useState("morning");
  const mobile    = useMobile();
  const cityIdx   = trip.cities.findIndex(c => c.id === city.id);
  const cityColor = CITY_PALETTE[Math.max(0, cityIdx) % CITY_PALETTE.length];
  const isToday   = day.date === today();

  const open = (block, activity = null) =>
    setActModal({ block, activity: activity || newActivity({ addedOnTrip: trip.status === "active" }), isNew: !activity });

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, flexShrink: 0, padding: mobile ? "12px 14px" : "14px 28px" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", display: "flex", alignItems: "center", gap: mobile ? 10 : 16 }}>
          <button onClick={onBack} style={{ background: "none", border: "none", color: C.mid, cursor: "pointer", fontSize: mobile ? 22 : 13, lineHeight: 1, padding: "0 2px" }}>
            {mobile ? "‹" : `← ${city.name}`}
          </button>
          <div style={{ width: 3, height: mobile ? 18 : 22, background: cityColor, borderRadius: 2 }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 20 : 26, fontWeight: 400, color: C.text, lineHeight: 1 }}>{day.label}</h2>
              {isToday && <Tag color={C.ok}>Today</Tag>}
            </div>
            <span style={{ color: C.mid, fontSize: 12 }}>{mobile ? `${city.name} · ` : ""}{day.date}</span>
          </div>
          <Btn variant="accent" size="sm" onClick={() => open(mobile ? mobileBlock : "morning")}>+ Activity</Btn>
        </div>

        {/* Mobile: block tab switcher */}
        {mobile && (
          <div style={{ display: "flex", gap: 0, marginTop: 10, borderTop: `1px solid ${C.border}`, paddingTop: 0 }}>
            {BLOCKS.map(bl => {
              const meta = BLOCK_META[bl];
              const cnt  = day.blocks[bl].length;
              return (
                <button key={bl} onClick={() => setMobileBlock(bl)} style={{
                  flex: 1, background: "none", border: "none", padding: "9px 4px",
                  fontSize: 13, fontWeight: 500, cursor: "pointer",
                  color: mobileBlock === bl ? meta.accent : C.mid,
                  borderBottom: `2px solid ${mobileBlock === bl ? meta.accent : "transparent"}`,
                  transition: "all 0.15s", display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
                }}>
                  {meta.icon} {meta.label}
                  {cnt > 0 && <span style={{ background: `${meta.accent}22`, color: meta.accent, borderRadius: 8, padding: "0 6px", fontSize: 10 }}>{cnt}</span>}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: mobile ? "14px" : "28px" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>

          {/* Desktop: 3-column grid */}
          {!mobile && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 22, marginBottom: 28 }}>
              {BLOCKS.map(block => <DayBlock key={block} block={block} day={day} open={open} />)}
            </div>
          )}

          {/* Mobile: single active block */}
          {mobile && (
            <div style={{ marginBottom: 20 }}>
              <DayBlock block={mobileBlock} day={day} open={open} />
            </div>
          )}

          {/* Reflection */}
          <SectionCard style={{ padding: "18px 20px" }}>
            <Textarea
              label="📖 Day reflection — saved in Look Back view"
              value={day.reflection}
              onChange={v => mutateDay(d => ({ ...d, reflection: v }))}
              placeholder="How was the day? Highlights, surprises, anything to remember for next time..."
              rows={2}
            />
          </SectionCard>
        </div>
      </div>

      {actModal && (
        <Modal onClose={() => setActModal(null)}>
          <ActivityModal
            activity={actModal.activity} block={actModal.block} isNew={actModal.isNew} currency={trip.currency}
            onSave={updates => { if (actModal.isNew) addActivity(actModal.block, { ...actModal.activity, ...updates }); else updateActivity(actModal.block, actModal.activity.id, updates); setActModal(null); }}
            onDelete={actModal.isNew ? null : () => { deleteActivity(actModal.block, actModal.activity.id); setActModal(null); }}
            onClose={() => setActModal(null)}
          />
        </Modal>
      )}
    </div>
  );
}

function DayBlock({ block, day, open }) {
  const meta = BLOCK_META[block];
  const acts = day.blocks[block];
  return (
    <div style={{ background: C.surface, borderRadius: 14, padding: "18px 16px", border: `1px solid ${C.border}` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16, paddingBottom: 12, borderBottom: `1px solid ${C.border}` }}>
        <span style={{ fontSize: 20 }}>{meta.icon}</span>
        <span style={{ fontWeight: 600, color: meta.accent, fontSize: 15 }}>{meta.label}</span>
        {acts.length > 0 && (
          <span style={{ marginLeft: "auto", background: `${meta.accent}22`, color: meta.accent, borderRadius: 8, padding: "1px 8px", fontSize: 11 }}>{acts.length}</span>
        )}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, minHeight: 60 }}>
        {acts.map(act => <ActivityCard key={act.id} activity={act} blockAccent={meta.accent} onClick={() => open(block, act)} />)}
      </div>
      <button onClick={() => open(block)} style={{
        marginTop: 12, width: "100%", background: "none",
        border: `1px dashed ${C.dim}`, borderRadius: 8, padding: "8px 0",
        color: C.dim, fontSize: 13, transition: "all 0.15s",
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = meta.accent; e.currentTarget.style.color = meta.accent; e.currentTarget.style.background = meta.dim; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = C.dim; e.currentTarget.style.color = C.dim; e.currentTarget.style.background = "none"; }}>
        + Add to {meta.label}
      </button>
    </div>
  );
}

function ActivityCard({ activity, blockAccent, onClick }) {
  const typeInfo = ACT_TYPES.find(t => t.id === activity.type) || ACT_TYPES[7];
  return (
    <div onClick={onClick} style={{
      background: C.surface2, borderRadius: 10, padding: "12px 14px",
      border: `1px solid ${activity.isConfirmed ? "rgba(92,184,122,0.3)" : C.border}`,
      cursor: "pointer", transition: "all 0.15s",
      opacity: activity.completed ? 0.55 : 1,
    }}
    onMouseEnter={e => { e.currentTarget.style.background = C.surface3; e.currentTarget.style.borderColor = `${blockAccent}44`; }}
    onMouseLeave={e => { e.currentTarget.style.background = C.surface2; e.currentTarget.style.borderColor = activity.isConfirmed ? "rgba(92,184,122,0.3)" : C.border; }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
        <span style={{ fontSize: 18, flexShrink: 0 }}>{typeInfo.icon}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 500, color: C.text, marginBottom: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {activity.title || <span style={{ color: C.dim, fontStyle: "italic" }}>Untitled</span>}
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
            {activity.time         && <span style={{ fontSize: 12, color: C.mid }}>{activity.time}</span>}
            {activity.duration     && <span style={{ fontSize: 12, color: C.dim }}>· {activity.duration}</span>}
            {activity.confirmation && <Tag color={C.ok}>✓ {activity.confirmation}</Tag>}
            {activity.addedOnTrip  && <Tag color={C.purple}>on trip</Tag>}
            {activity.completed    && <Tag color={C.dim}>done</Tag>}
          </div>
          {activity.location && <div style={{ fontSize: 11, color: C.dim, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>📍 {activity.location}</div>}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ACTIVITY MODAL
═══════════════════════════════════════════════════════════════ */
function ActivityModal({ activity, block, isNew, currency, onSave, onDelete, onClose }) {
  const [form, setForm] = useState({ ...activity, cost: { ...activity.cost }, references: activity.references ? activity.references.map(r => ({ ...r })) : [] });
  const [tab, setTab] = useState("details");
  const upd     = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const updCost = (k, v) => setForm(f => ({ ...f, cost: { ...f.cost, [k]: v } }));
  const addRef  = ()     => setForm(f => ({ ...f, references: [...f.references, { id: uid(), url: "", label: "", notes: "" }] }));
  const updRef  = (id, k, v) => setForm(f => ({ ...f, references: f.references.map(r => r.id === id ? { ...r, [k]: v } : r) }));
  const delRef  = (id)       => setForm(f => ({ ...f, references: f.references.filter(r => r.id !== id) }));
  const meta    = BLOCK_META[block] || BLOCK_META.morning;
  const tabs    = [
    { id: "details",    label: "📋 Details" },
    { id: "cost",       label: "💰 Cost" },
    { id: "references", label: `🔗 Refs${form.references.length ? ` (${form.references.length})` : ""}` },
    { id: "transit",    label: "🚇 Transit" },
  ];

  return (
    <div>
      <div style={{ padding: "20px 24px 0", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
          <select value={form.type} onChange={e => upd("type", e.target.value)} style={{ width: 170, flexShrink: 0 }}>
            {ACT_TYPES.map(t => <option key={t.id} value={t.id}>{t.icon} {t.label}</option>)}
          </select>
          <input value={form.title} onChange={e => upd("title", e.target.value)} placeholder="Activity title..." style={{ flex: 1, fontSize: 18, fontFamily: "'Cormorant Garamond', serif" }} />
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22, padding: "0 4px" }}>×</button>
        </div>
        <div style={{ display: "flex", gap: 0 }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              background: "none", border: "none", padding: "9px 14px", fontSize: 13,
              fontWeight: 500, cursor: "pointer", transition: "all 0.15s",
              color: tab === t.id ? meta.accent : C.mid,
              borderBottom: `2px solid ${tab === t.id ? meta.accent : "transparent"}`,
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "20px 24px", overflowY: "auto", maxHeight: "58vh" }}>
        {tab === "details" && (
          <div style={{ display: "grid", gap: 14 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
              <Input label="Time" value={form.time} onChange={v => upd("time", v)} placeholder="14:30" />
              <Input label="Duration" value={form.duration} onChange={v => upd("duration", v)} placeholder="2h 30m" />
              <Input label="Confirmation #" value={form.confirmation} onChange={v => upd("confirmation", v)} placeholder="ABC123" />
            </div>
            <Input label="Location / Address" value={form.location} onChange={v => upd("location", v)} placeholder="Where is this?" />
            <Textarea label="Notes" value={form.notes} onChange={v => upd("notes", v)} placeholder="Tips, reminders, access info..." rows={3} />
            <div style={{ display: "flex", gap: 24 }}>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 14, color: C.mid }}>
                <input type="checkbox" checked={form.isConfirmed} onChange={e => upd("isConfirmed", e.target.checked)} /> Confirmed / booked
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 14, color: C.mid }}>
                <input type="checkbox" checked={form.addedOnTrip} onChange={e => upd("addedOnTrip", e.target.checked)} /> Added during trip
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 14, color: C.mid }}>
                <input type="checkbox" checked={form.completed} onChange={e => upd("completed", e.target.checked)} /> Completed
              </label>
            </div>
          </div>
        )}

        {tab === "cost" && (
          <div style={{ display: "grid", gap: 14 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label={`Estimated (${currency})`} value={form.cost.estimated} onChange={v => updCost("estimated", v)} placeholder="0.00" type="number" />
              <Input label={`Confirmed (${currency})`} value={form.cost.confirmed} onChange={v => updCost("confirmed", v)} placeholder="0.00" type="number" />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Sel label="Paid by" value={form.cost.paidBy} onChange={v => updCost("paidBy", v)} options={[{value:"you",label:"You"},{value:"partner",label:"Partner"},{value:"split",label:"Split"},{value:"comp",label:"Comp / Free"}]} />
              <Sel label="Category" value={form.cost.category} onChange={v => updCost("category", v)} options={COST_CATS} />
            </div>
            <Input label="Cost notes" value={form.cost.notes} onChange={v => updCost("notes", v)} placeholder='e.g., "Booked on points, includes tip..."' />
            <div style={{ background: C.accentBg, borderRadius: 8, padding: "10px 14px", border: `1px solid ${C.accentBdr}`, fontSize: 12, color: C.mid, lineHeight: 1.6 }}>
              <strong style={{ color: C.accent }}>💡 Future:</strong> Multi-currency — each activity will store a local currency amount (e.g., ¥12,400) alongside a converted base-currency value for the budget summary.
            </div>
          </div>
        )}

        {tab === "references" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {form.references.length === 0 && <p style={{ color: C.dim, fontSize: 14, fontStyle: "italic" }}>No references yet. Add booking links, research pages, or any URLs for this activity.</p>}
            {form.references.map(ref => (
              <div key={ref.id} style={{ background: C.surface2, borderRadius: 10, padding: 14, border: `1px solid ${C.border}` }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                  <Input label="URL" value={ref.url} onChange={v => updRef(ref.id, "url", v)} placeholder="https://..." />
                  <Input label="Label" value={ref.label} onChange={v => updRef(ref.id, "label", v)} placeholder='"Reserve here"' />
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
                  <div style={{ flex: 1 }}><Input label="Notes" value={ref.notes} onChange={v => updRef(ref.id, "notes", v)} placeholder="Research notes..." /></div>
                  <button onClick={() => delRef(ref.id)} style={{ background: "none", border: "none", color: C.warn, cursor: "pointer", fontSize: 18, paddingBottom: 8 }}>✕</button>
                </div>
              </div>
            ))}
            <Btn variant="ghost" size="sm" onClick={addRef}>+ Add Reference</Btn>
          </div>
        )}

        {tab === "transit" && (
          <div style={{ display: "grid", gap: 14 }}>
            <Textarea
              label="Step-by-step transit directions"
              value={form.transitSteps} onChange={v => upd("transitSteps", v)}
              placeholder={"1. Take Metro Line 5 (Bobigny) from République\n2. Transfer at Châtelet → Line 1 (La Défense)\n3. Exit at Palais Royal — Musée du Louvre\n4. Follow signs to Richelieu Wing entrance"}
              rows={9}
            />
            <p style={{ fontSize: 12, color: C.dim }}>These directions appear in Travel Mode when this is the current or next activity.</p>
          </div>
        )}
      </div>

      <div style={{ padding: "14px 24px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>{!isNew && onDelete && <Btn variant="danger" size="sm" onClick={onDelete}>Delete</Btn>}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="ghost"  onClick={onClose}>Cancel</Btn>
          <Btn variant="accent" onClick={() => onSave(form)}>{isNew ? "Add Activity" : "Save Changes"}</Btn>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   VAULT VIEW
═══════════════════════════════════════════════════════════════ */
function VaultView({ activities, currency }) {
  const mobile = useMobile();
  const [q, setQ] = useState("");
  const filtered  = activities.filter(a =>
    [a.title, a.confirmation, a.cityName, a.location].some(s => s?.toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: mobile ? "20px 14px" : "36px 28px" }}>
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 26 : 32, color: C.text, marginBottom: 6 }}>🔑 Confirmation Vault</h2>
      <p style={{ color: C.mid, fontSize: 14, marginBottom: 20 }}>Every confirmation number, always one search away.</p>
      <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search confirmations..." style={{ marginBottom: 16 }} />
      {filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "48px 0", color: C.dim }}>
          {activities.length === 0 ? "No confirmation numbers yet. Add them on activity cards." : "No matches."}
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {filtered.map(a => {
            const t = ACT_TYPES.find(x => x.id === a.type) || ACT_TYPES[7];
            return (
              <div key={a.id + a.date} style={{ background: C.surface, borderRadius: 12, padding: mobile ? "14px 16px" : "16px 22px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: mobile ? 12 : 18 }}>
                <span style={{ fontSize: 22 }}>{t.icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 15, fontWeight: 500, color: C.text, marginBottom: 2 }}>{a.title}</div>
                  <div style={{ fontSize: 12, color: C.mid }}>{a.cityName} · {a.date}</div>
                  {a.location && !mobile && <div style={{ fontSize: 12, color: C.dim, marginTop: 2 }}>📍 {a.location}</div>}
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontFamily: "monospace", fontSize: mobile ? 17 : 22, color: C.ok, letterSpacing: "0.06em", fontWeight: 700 }}>{a.confirmation}</div>
                  {a.time && <div style={{ fontSize: 12, color: C.dim, marginTop: 2 }}>{a.time}</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>

/* ═══════════════════════════════════════════════════════════════
   BUDGET VIEW
═══════════════════════════════════════════════════════════════ */
function BudgetView({ activities, currency, travelers }) {
  const mobile = useMobile();
  const withCost = activities.filter(a => a.cost?.estimated || a.cost?.confirmed);
  const t1 = travelers[0] || "You";
  const t2 = travelers[1] || "Partner";

  const totals = withCost.reduce((acc, a) => {
    const est  = parseFloat(a.cost.estimated || 0);
    const conf = parseFloat(a.cost.confirmed  || 0);
    const val  = conf || est;
    acc.estimated += est; acc.actual += val;
    if (a.cost.paidBy === "you")     acc.byT1 += val;
    if (a.cost.paidBy === "partner") acc.byT2 += val;
    return acc;
  }, { estimated: 0, actual: 0, byT1: 0, byT2: 0 });

  const diff  = totals.byT1 - totals.byT2;
  const byCategory = COST_CATS.map(cat => ({
    cat, total: withCost.filter(a => a.cost.category === cat).reduce((s, a) => s + parseFloat(a.cost.confirmed || a.cost.estimated || 0), 0),
  })).filter(x => x.total > 0).sort((a, b) => b.total - a.total);

  const byCity = activities.reduce((acc, a) => {
    if (!a.cost?.estimated && !a.cost?.confirmed) return acc;
    const val = parseFloat(a.cost.confirmed || a.cost.estimated || 0);
    acc[a.cityName] = (acc[a.cityName] || 0) + val;
    return acc;
  }, {});

  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: mobile ? "20px 14px" : "36px 28px" }}>
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: mobile ? 26 : 32, color: C.text, marginBottom: mobile ? 18 : 24 }}>💰 Budget Summary</h2>

      <div style={{ display: "grid", gridTemplateColumns: mobile ? "1fr" : "repeat(3, 1fr)", gap: mobile ? 10 : 16, marginBottom: mobile ? 18 : 28 }}>
        {[
          { label: "Estimated Total",  value: fmt(totals.estimated, currency), color: C.mid },
          { label: "Actual / Confirmed", value: fmt(totals.actual, currency),  color: C.ok },
          { label: diff === 0 ? "All square!" : diff > 0 ? `${t2} owes ${t1}` : `${t1} owes ${t2}`, value: fmt(Math.abs(diff), currency), color: diff === 0 ? C.ok : C.accent },
        ].map(card => (
          <div key={card.label} style={{ background: C.surface, borderRadius: 12, padding: "20px 18px", border: `1px solid ${C.border}`, textAlign: "center" }}>
            <div style={{ fontSize: 11, color: C.mid, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>{card.label}</div>
            <div style={{ fontSize: 26, fontWeight: 600, color: card.color, fontFamily: "'Cormorant Garamond', serif" }}>{card.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: mobile ? "1fr" : "1fr 1fr", gap: 16, marginBottom: 16 }}>
        {byCategory.length > 0 && (
          <SectionCard style={{ padding: "20px 22px" }}>
            <h3 style={{ color: C.text, marginBottom: 16, fontSize: 15, fontWeight: 500 }}>By Category</h3>
            {byCategory.map(({ cat, total }) => {
              const pct = totals.actual > 0 ? (total / totals.actual) * 100 : 0;
              return (
                <div key={cat} style={{ marginBottom: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 14, color: C.text }}>{cat}</span>
                    <span style={{ fontSize: 13, color: C.mid }}>{fmt(total, currency)}</span>
                  </div>
                  <div style={{ height: 5, background: C.surface3, borderRadius: 3 }}>
                    <div style={{ height: "100%", width: `${pct}%`, background: C.accent, borderRadius: 3 }} />
                  </div>
                </div>
              );
            })}
          </SectionCard>
        )}
        {Object.keys(byCity).length > 0 && (
          <SectionCard style={{ padding: "20px 22px" }}>
            <h3 style={{ color: C.text, marginBottom: 16, fontSize: 15, fontWeight: 500 }}>By City</h3>
            {Object.entries(byCity).sort((a, b) => b[1] - a[1]).map(([city, total], i) => (
              <div key={city} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ width: 10, height: 10, borderRadius: "50%", background: CITY_PALETTE[i % CITY_PALETTE.length] }} />
                  <span style={{ fontSize: 14, color: C.text }}>{city}</span>
                </div>
                <span style={{ fontSize: 14, color: C.mid }}>{fmt(total, currency)}</span>
              </div>
            ))}
          </SectionCard>
        )}
      </div>

      {/* Bill split */}
      <SectionCard style={{ padding: "20px 22px", marginBottom: 20 }}>
        <h3 style={{ color: C.text, marginBottom: 14, fontSize: 15, fontWeight: 500 }}>Bill Split</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 14 }}>
          {[[t1, totals.byT1], [t2, totals.byT2]].map(([who, amt]) => (
            <div key={who} style={{ background: C.surface2, borderRadius: 8, padding: "12px 16px" }}>
              <div style={{ fontSize: 12, color: C.mid, marginBottom: 4 }}>{who} paid</div>
              <div style={{ fontSize: 22, fontFamily: "'Cormorant Garamond', serif", color: C.text }}>{fmt(amt, currency)}</div>
            </div>
          ))}
        </div>
        {diff !== 0 && (
          <div style={{ padding: "12px 16px", background: C.accentBg, borderRadius: 8, border: `1px solid ${C.accentBdr}`, fontSize: 14, color: C.accent }}>
            <strong>{diff > 0 ? t2 : t1}</strong> owes <strong>{fmt(Math.abs(diff), currency)}</strong> to even things out.
          </div>
        )}
        {diff === 0 && totals.actual > 0 && (
          <div style={{ padding: "12px 16px", background: C.okBg, borderRadius: 8, border: `1px solid ${C.okBdr}`, fontSize: 14, color: C.ok }}>
            ✓ All square — expenses are evenly split!
          </div>
        )}
      </SectionCard>

      <div style={{ background: C.accentBg, borderRadius: 8, padding: "12px 16px", border: `1px solid ${C.accentBdr}`, fontSize: 12, color: C.mid }}>
        <strong style={{ color: C.accent }}>💡 Future:</strong> Multi-currency — local amounts (¥, €, £) stored per activity with conversion to your base currency, so this summary works even for mixed-currency trips.
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   NEW TRIP + NEW CITY MODALS
═══════════════════════════════════════════════════════════════ */
function NewTripModal({ onSave, onClose }) {
  const [form, setForm] = useState({ title: "", startDate: "", endDate: "", currency: "USD", ptoDays: "" });
  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const auto = getPTODays(form.startDate, form.endDate);
  const valid = form.title.trim() && form.startDate && form.endDate;
  return (
    <div style={{ padding: 28 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: C.text }}>New Trip</h2>
          <p style={{ color: C.mid, fontSize: 13, marginTop: 4 }}>Cities and activities can be added after creating.</p>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
      </div>
      <div style={{ display: "grid", gap: 16 }}>
        <Input label="Trip title" value={form.title} onChange={v => upd("title", v)} placeholder="e.g., Japan Spring 2025, Portugal Anniversary..." />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Input label="Start date" type="date" value={form.startDate} onChange={v => upd("startDate", v)} />
          <Input label="End date"   type="date" value={form.endDate}   onChange={v => upd("endDate", v)} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Input label="Currency code" value={form.currency} onChange={v => upd("currency", v)} placeholder="USD" />
          <Field label="PTO days used">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input type="number" value={form.ptoDays} onChange={e => upd("ptoDays", e.target.value)} placeholder={auto || "e.g., 9"} style={{ flex: 1 }} />
              {auto > 0 && <Btn size="sm" variant="ghost" onClick={() => upd("ptoDays", auto)}>Use {auto}</Btn>}
            </div>
            {auto > 0 && <span style={{ fontSize: 11, color: C.dim, marginTop: 4 }}>Auto-calculated: {auto} weekdays</span>}
          </Field>
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 24 }}>
        <Btn variant="ghost"  onClick={onClose}>Cancel</Btn>
        <Btn variant="accent" disabled={!valid} onClick={() => onSave(newTrip(form))}>Create Trip</Btn>
      </div>
    </div>
  );
}

function NewCityModal({ existingCities, onSave, onClose }) {
  const nextStart = (() => {
    if (!existingCities.length) return "";
    const last    = existingCities[existingCities.length - 1];
    const lastDay = last.days[last.days.length - 1]?.date;
    if (!lastDay) return "";
    const d = new Date(lastDay + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + 1);
    return d.toISOString().split("T")[0];
  })();
  const [form, setForm] = useState({ name: "", nights: 3, startDate: nextStart });
  const upd   = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const valid = form.name.trim() && form.nights > 0 && form.startDate;
  return (
    <div style={{ padding: 28 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: C.text }}>Add City / Segment</h2>
          <p style={{ color: C.mid, fontSize: 13, marginTop: 4 }}>Days are auto-generated from the start date.</p>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
      </div>
      <div style={{ display: "grid", gap: 16 }}>
        <Input label="City name" value={form.name} onChange={v => upd("name", v)} placeholder="e.g., Kyoto, Paris, Lisbon..." />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Input label="Number of nights" type="number" value={form.nights} onChange={v => upd("nights", Math.max(1, parseInt(v) || 1))} />
          <Input label="Arrival date" type="date" value={form.startDate} onChange={v => upd("startDate", v)} />
        </div>
        {existingCities.length > 0 && (
          <div style={{ background: C.surface2, borderRadius: 8, padding: "10px 14px", fontSize: 13, color: C.mid }}>
            Will follow <strong style={{ color: C.text }}>{existingCities[existingCities.length - 1].name}</strong> in the city ribbon.
          </div>
        )}
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 24 }}>
        <Btn variant="ghost"  onClick={onClose}>Cancel</Btn>
        <Btn variant="accent" disabled={!valid} onClick={() => onSave(newCity(form.name.trim(), parseInt(form.nights), form.startDate))}>Add City</Btn>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   IMPORT / EXPORT MODAL
═══════════════════════════════════════════════════════════════ */
function ImportExportModal({ trips, currentTrip, onImport, onClose }) {
  const [tab,       setTab]       = useState(currentTrip ? "export" : "import");
  const [importing, setImporting] = useState(false);
  const [result,    setResult]    = useState(null); // { ok, message, trips? }
  const [preview,   setPreview]   = useState(null); // trips to confirm import
  const fileRef = useRef(null);

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setResult(null);
    setImporting(true);
    try {
      const parsed  = await readJSONFile(file);
      const imported = validateImport(parsed);
      setPreview(imported);
    } catch (err) {
      setResult({ ok: false, message: err.message });
    } finally {
      setImporting(false);
      e.target.value = "";
    }
  };

  const confirmImport = (mode) => {
    // mode: "add" = add alongside existing | "replace" = wipe and replace
    const stamped = preview.map(restampIds);
    onImport(stamped, mode);
    setPreview(null);
    setResult({ ok: true, message: `${stamped.length} trip${stamped.length > 1 ? "s" : ""} imported successfully!` });
  };

  const exportRow = (label, desc, icon, onClick) => (
    <button onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 16,
      background: C.surface2, border: `1px solid ${C.border}`, borderRadius: 12,
      padding: "16px 20px", cursor: "pointer", width: "100%", textAlign: "left",
      transition: "all 0.15s",
    }}
    onMouseEnter={e => { e.currentTarget.style.borderColor = C.accentBdr; e.currentTarget.style.background = C.surface3; }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = C.border;    e.currentTarget.style.background = C.surface2; }}
    >
      <span style={{ fontSize: 28, flexShrink: 0 }}>{icon}</span>
      <div>
        <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 3 }}>{label}</div>
        <div style={{ fontSize: 12, color: C.mid }}>{desc}</div>
      </div>
      <span style={{ marginLeft: "auto", fontSize: 18, color: C.dim }}>↓</span>
    </button>
  );

  const tabs = [
    { id: "export", label: "📤 Export" },
    { id: "import", label: "📥 Import" },
  ];

  return (
    <div>
      {/* Header */}
      <div style={{ padding: "22px 24px 0", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, color: C.text }}>Import / Export</h2>
            <p style={{ color: C.mid, fontSize: 13, marginTop: 3 }}>Back up your trips, share them, or bring data in from a file.</p>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
        </div>
        <div style={{ display: "flex" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => { setTab(t.id); setResult(null); setPreview(null); }} style={{
              background: "none", border: "none", padding: "9px 18px", fontSize: 14, fontWeight: 500,
              cursor: "pointer", color: tab === t.id ? C.accent : C.mid,
              borderBottom: `2px solid ${tab === t.id ? C.accent : "transparent"}`,
              transition: "all 0.15s",
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "22px 24px" }}>

        {/* ── EXPORT TAB ── */}
        {tab === "export" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {currentTrip && (
              <>
                <p style={{ fontSize: 13, color: C.mid, marginBottom: 4 }}>
                  Exporting: <strong style={{ color: C.text }}>{currentTrip.title}</strong>
                </p>
                {exportRow(
                  "Export Trip as JSON",
                  "Full backup of this trip — all cities, activities, costs, notes. Re-importable.",
                  "💾",
                  () => exportTripJSON(currentTrip)
                )}
                {exportRow(
                  "Export Budget as CSV",
                  "All activities with costs in a spreadsheet-ready format. Open in Excel or Google Sheets.",
                  "📊",
                  () => exportBudgetCSV(currentTrip)
                )}
                {exportRow(
                  "Export Itinerary as Markdown",
                  "Human-readable trip summary with all days, activities, and reflections.",
                  "📄",
                  () => exportItineraryMD(currentTrip)
                )}
                <div style={{ height: 1, background: C.border, margin: "8px 0" }} />
              </>
            )}
            {exportRow(
              `Export All Trips as JSON (${trips.length})`,
              "Complete backup of every trip in Journey. Restore everything in one import.",
              "🗂️",
              () => exportAllJSON(trips)
            )}
            <div style={{ background: C.surface2, borderRadius: 10, padding: "12px 16px", fontSize: 12, color: C.dim, lineHeight: 1.7, marginTop: 4 }}>
              <strong style={{ color: C.mid }}>JSON</strong> files are fully re-importable and preserve all data.{" "}
              <strong style={{ color: C.mid }}>CSV</strong> is for spreadsheet analysis only — it cannot be re-imported.{" "}
              <strong style={{ color: C.mid }}>Markdown</strong> is a portable text format — great for sharing or printing.
            </div>
          </div>
        )}

        {/* ── IMPORT TAB ── */}
        {tab === "import" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

            {/* Drop zone */}
            {!preview && (
              <>
                <div
                  onClick={() => fileRef.current?.click()}
                  style={{
                    border: `2px dashed ${C.dim}`, borderRadius: 14,
                    padding: "40px 24px", textAlign: "center", cursor: "pointer",
                    transition: "all 0.2s",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = C.accent; e.currentTarget.style.background = C.accentBg; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = C.dim;    e.currentTarget.style.background = "transparent"; }}
                  onDragOver={e  => { e.preventDefault(); e.currentTarget.style.borderColor = C.accent; e.currentTarget.style.background = C.accentBg; }}
                  onDragLeave={e => { e.currentTarget.style.borderColor = C.dim;    e.currentTarget.style.background = "transparent"; }}
                  onDrop={e => {
                    e.preventDefault();
                    e.currentTarget.style.borderColor = C.dim; e.currentTarget.style.background = "transparent";
                    const file = e.dataTransfer.files?.[0];
                    if (file) { const dt = new DataTransfer(); dt.items.add(file); fileRef.current.files = dt.files; handleFileChange({ target: fileRef.current }); }
                  }}
                >
                  <div style={{ fontSize: 36, marginBottom: 12 }}>📂</div>
                  <div style={{ fontSize: 15, color: C.text, marginBottom: 6, fontWeight: 500 }}>
                    {importing ? "Reading file…" : "Click or drag a Journey JSON file here"}
                  </div>
                  <div style={{ fontSize: 13, color: C.dim }}>Accepts .json files exported from Journey</div>
                </div>
                <input ref={fileRef} type="file" accept=".json,application/json"
                  onChange={handleFileChange} style={{ display: "none" }} />
              </>
            )}

            {/* Preview */}
            {preview && !result && (
              <div style={{ animation: "fadeSlideIn 0.2s ease" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                  <span style={{ fontSize: 20 }}>📋</span>
                  <h3 style={{ color: C.text, fontSize: 16 }}>
                    Found {preview.length} trip{preview.length > 1 ? "s" : ""} — confirm import
                  </h3>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
                  {preview.map((t, i) => (
                    <div key={i} style={{ background: C.surface2, borderRadius: 10, padding: "12px 16px", border: `1px solid ${C.border}` }}>
                      <div style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 4 }}>{t.title}</div>
                      <div style={{ fontSize: 12, color: C.mid }}>
                        {t.startDate} → {t.endDate} · {t.cities?.length || 0} cities · {getAllActivities(t).length} activities
                      </div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
                        {t.cities?.map((c, ci) => (
                          <span key={ci} style={{ fontSize: 11, padding: "2px 8px", borderRadius: 8, background: `${CITY_PALETTE[ci % CITY_PALETTE.length]}22`, color: CITY_PALETTE[ci % CITY_PALETTE.length] }}>
                            {c.name} · {c.nights}n
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <Btn variant="accent" onClick={() => confirmImport("add")} style={{ flex: 1 }}>
                    ➕ Add alongside existing trips
                  </Btn>
                  <Btn variant="danger" onClick={() => confirmImport("replace")} style={{ flex: 1 }}>
                    ⚠️ Replace all trips
                  </Btn>
                </div>
                <p style={{ fontSize: 12, color: C.dim, marginTop: 10, textAlign: "center" }}>
                  "Replace" will permanently overwrite your current trips. "Add" is always safe.
                </p>
                <Btn variant="ghost" size="sm" onClick={() => setPreview(null)} style={{ marginTop: 8 }}>← Choose a different file</Btn>
              </div>
            )}

            {/* Result */}
            {result && (
              <div style={{
                padding: "20px 22px", borderRadius: 12, textAlign: "center",
                background: result.ok ? C.okBg : C.warnBg,
                border: `1px solid ${result.ok ? C.okBdr : C.warnBdr}`,
                animation: "fadeSlideIn 0.2s ease",
              }}>
                <div style={{ fontSize: 32, marginBottom: 10 }}>{result.ok ? "✅" : "❌"}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: result.ok ? C.ok : C.warn, marginBottom: 6 }}>
                  {result.ok ? "Import Successful" : "Import Failed"}
                </div>
                <div style={{ fontSize: 13, color: C.mid }}>{result.message}</div>
                {!result.ok && (
                  <Btn size="sm" variant="ghost" onClick={() => { setResult(null); setPreview(null); }} style={{ marginTop: 14 }}>
                    Try again
                  </Btn>
                )}
              </div>
            )}

            {/* Format notes */}
            {!preview && !result && (
              <div style={{ background: C.surface2, borderRadius: 10, padding: "12px 16px", fontSize: 12, color: C.dim, lineHeight: 1.8 }}>
                <strong style={{ color: C.mid, display: "block", marginBottom: 4 }}>What can be imported?</strong>
                ✓ Journey JSON exports (single trip or all trips)<br />
                ✓ Files exported from this app on another device<br />
                ✗ CSV or Markdown files (export-only formats)
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   PREP CHECKLIST (per-trip tab)
═══════════════════════════════════════════════════════════════ */
function PrepChecklist({ trip, mutateTrip, templates, setModal }) {
  const mobile = useMobile();
  const items = trip.prepChecklist || [];
  const [filter, setFilter] = useState("all");   // all | trip | city | day | incomplete
  const [addingScope, setAddingScope]     = useState(null); // null | "trip"|"city"|"day"
  const [draft, setDraft] = useState({ text: "", category: "Other", priority: "normal", notes: "", scope: "trip", cityId: "", dayId: "" });
  const upd = (k, v) => setDraft(d => ({ ...d, [k]: v }));

  const save = () => {
    if (!draft.text.trim()) return;
    mutateTrip(t => ({ ...t, prepChecklist: [...(t.prepChecklist || []), newPrepItem(draft)] }));
    setDraft({ text: "", category: "Other", priority: "normal", notes: "", scope: "trip", cityId: draft.cityId, dayId: "" });
    setAddingScope(null);
  };

  const toggle = (id) => mutateTrip(t => ({
    ...t, prepChecklist: (t.prepChecklist || []).map(i =>
      i.id === id ? { ...i, completed: !i.completed, completedAt: !i.completed ? new Date().toISOString() : null } : i
    ),
  }));
  const deleteItem = (id) => mutateTrip(t => ({ ...t, prepChecklist: (t.prepChecklist || []).filter(i => i.id !== id) }));
  const updateItem = (id, patch) => mutateTrip(t => ({ ...t, prepChecklist: (t.prepChecklist || []).map(i => i.id === id ? { ...i, ...patch } : i) }));

  const allCityDays = trip.cities.flatMap(c => c.days.map(d => ({ ...d, cityId: c.id, cityName: c.name })));

  const filtered = items.filter(i => {
    if (filter === "incomplete") return !i.completed;
    if (filter === "trip")  return i.scope === "trip";
    if (filter === "city")  return i.scope === "city";
    if (filter === "day")   return i.scope === "day";
    return true;
  });

  // Group for display
  const tripItems  = filtered.filter(i => i.scope === "trip");
  const cityItems  = filtered.filter(i => i.scope === "city");
  const dayItems   = filtered.filter(i => i.scope === "day");

  const total     = items.length;
  const done      = items.filter(i => i.completed).length;
  const pct       = total > 0 ? Math.round((done / total) * 100) : 0;

  const scopedCity = trip.cities.find(c => c.id === draft.cityId);
  const scopedDays = scopedCity?.days || [];

  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: mobile ? "20px 14px" : "32px 28px" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, color: C.text }}>📋 Pre-Trip Checklist</h2>
          <p style={{ color: C.mid, fontSize: 13, marginTop: 4 }}>Everything to do before you leave.</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="ghost" size="sm" onClick={() => setModal({ type: "importTemplate", tripId: trip.id })}>
            📥 Import Template
          </Btn>
          <Btn variant="accent" size="sm" onClick={() => setAddingScope("trip")}>+ Add Item</Btn>
        </div>
      </div>

      {/* Progress bar */}
      {total > 0 && (
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: C.mid }}>{done} of {total} complete</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: pct === 100 ? C.ok : C.accent }}>{pct}%</span>
          </div>
          <div style={{ height: 6, background: C.surface3, borderRadius: 4 }}>
            <div style={{
              height: "100%", width: `${pct}%`, borderRadius: 4,
              background: pct === 100 ? C.ok : C.accent,
              transition: "width 0.4s ease",
            }} />
          </div>
          {pct === 100 && (
            <div style={{ marginTop: 10, color: C.ok, fontSize: 13, fontWeight: 500, display: "flex", alignItems: "center", gap: 6 }}>
              ✅ All done — you're ready to travel!
            </div>
          )}
        </div>
      )}

      {/* Filter pills */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
        {[
          { id: "all",        label: `All (${total})` },
          { id: "incomplete", label: `To do (${total - done})` },
          { id: "trip",       label: `✈️ Trip-level (${items.filter(i=>i.scope==="trip").length})` },
          { id: "city",       label: `🏙️ City (${items.filter(i=>i.scope==="city").length})` },
          { id: "day",        label: `📅 Day (${items.filter(i=>i.scope==="day").length})` },
        ].map(f => (
          <button key={f.id} onClick={() => setFilter(f.id)} style={{
            padding: "5px 14px", borderRadius: 20, fontSize: 12, fontWeight: 500,
            background: filter === f.id ? C.accent : C.surface2,
            color: filter === f.id ? "#0c0e16" : C.mid,
            border: `1px solid ${filter === f.id ? C.accent : C.border}`,
            cursor: "pointer", transition: "all 0.15s",
          }}>{f.label}</button>
        ))}
      </div>

      {/* Add item form */}
      {addingScope && (
        <div style={{ background: C.surface2, borderRadius: 12, padding: 20, marginBottom: 24, border: `1px solid ${C.accentBdr}`, animation: "fadeSlideIn 0.2s ease" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h4 style={{ color: C.text, fontSize: 15 }}>New Checklist Item</h4>
            <button onClick={() => setAddingScope(null)} style={{ background: "none", border: "none", color: C.dim, fontSize: 18 }}>×</button>
          </div>
          <div style={{ display: "grid", gap: 12 }}>
            <Input label="What needs to be done?" value={draft.text} onChange={v => upd("text", v)} placeholder='e.g., "Reserve dinner at Kyoto restaurant"' />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
              <Sel label="Category"  value={draft.category} onChange={v => upd("category", v)} options={PREP_CATS} />
              <Sel label="Priority"  value={draft.priority} onChange={v => upd("priority", v)} options={PREP_PRIO.map(p => ({ value: p.id, label: p.label }))} />
              <Sel label="Scope"     value={draft.scope}    onChange={v => { upd("scope", v); upd("cityId", ""); upd("dayId", ""); }}
                options={PREP_SCOPES.map(s => ({ value: s.id, label: s.label }))} />
            </div>
            {draft.scope !== "trip" && trip.cities.length > 0 && (
              <Sel label="Which city?" value={draft.cityId} onChange={v => { upd("cityId", v); upd("dayId", ""); }}
                options={[{ value: "", label: "— Select city —" }, ...trip.cities.map(c => ({ value: c.id, label: c.name }))]} />
            )}
            {draft.scope === "day" && scopedDays.length > 0 && (
              <Sel label="Which day?" value={draft.dayId} onChange={v => upd("dayId", v)}
                options={[{ value: "", label: "— Select day —" }, ...scopedDays.map(d => ({ value: d.id, label: `${d.label} (${d.date})` }))]} />
            )}
            <Input label="Notes (optional)" value={draft.notes} onChange={v => upd("notes", v)} placeholder="Any context, timing, or links..." />
            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="accent" onClick={save} disabled={!draft.text.trim()}>Add Item</Btn>
              <Btn variant="ghost"  onClick={() => setAddingScope(null)}>Cancel</Btn>
            </div>
          </div>
        </div>
      )}

      {/* Empty state */}
      {total === 0 && (
        <div style={{ textAlign: "center", padding: "52px 0", color: C.dim }}>
          <div style={{ fontSize: 44, marginBottom: 14 }}>📋</div>
          <p style={{ fontSize: 16, color: C.mid, marginBottom: 6 }}>No checklist items yet.</p>
          <p style={{ fontSize: 13, marginBottom: 20 }}>Add items manually or import a template to get started fast.</p>
          <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
            <Btn variant="accent" onClick={() => setAddingScope("trip")}>+ Add Item</Btn>
            <Btn variant="ghost"  onClick={() => setModal({ type: "importTemplate", tripId: trip.id })}>📥 Import Template</Btn>
          </div>
        </div>
      )}

      {/* Trip-level items */}
      {tripItems.length > 0 && (
        <PrepSection title="✈️ Trip-level" items={tripItems} trip={trip}
          onToggle={toggle} onDelete={deleteItem} onUpdate={updateItem} />
      )}

      {/* City-specific items, grouped by city */}
      {cityItems.length > 0 && (
        <>
          {trip.cities.map((c, ci) => {
            const cItems = cityItems.filter(i => i.cityId === c.id);
            if (!cItems.length) return null;
            return (
              <PrepSection key={c.id}
                title={`🏙️ ${c.name}`}
                color={CITY_PALETTE[ci % CITY_PALETTE.length]}
                items={cItems} trip={trip}
                onToggle={toggle} onDelete={deleteItem} onUpdate={updateItem} />
            );
          })}
          {/* City items with no city assigned */}
          {cityItems.filter(i => !i.cityId).length > 0 && (
            <PrepSection title="🏙️ City (unassigned)" items={cityItems.filter(i => !i.cityId)} trip={trip}
              onToggle={toggle} onDelete={deleteItem} onUpdate={updateItem} />
          )}
        </>
      )}

      {/* Day-specific items, grouped by city then day */}
      {dayItems.length > 0 && (
        <>
          {trip.cities.map((c, ci) => {
            return c.days.map(d => {
              const dItems = dayItems.filter(i => i.dayId === d.id);
              if (!dItems.length) return null;
              return (
                <PrepSection key={d.id}
                  title={`📅 ${c.name} · ${d.label}`}
                  subtitle={d.date}
                  color={CITY_PALETTE[ci % CITY_PALETTE.length]}
                  items={dItems} trip={trip}
                  onToggle={toggle} onDelete={deleteItem} onUpdate={updateItem} />
              );
            });
          })}
          {dayItems.filter(i => !i.dayId).length > 0 && (
            <PrepSection title="📅 Day (unassigned)" items={dayItems.filter(i => !i.dayId)} trip={trip}
              onToggle={toggle} onDelete={deleteItem} onUpdate={updateItem} />
          )}
        </>
      )}

      {/* Filtered empty state */}
      {total > 0 && filtered.length === 0 && (
        <div style={{ textAlign: "center", padding: "32px 0", color: C.dim, fontSize: 14 }}>
          No items match this filter.
        </div>
      )}
    </div>
  );
}

function PrepSection({ title, subtitle, color, items, trip, onToggle, onDelete, onUpdate }) {
  const done = items.filter(i => i.completed).length;
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        {color && <div style={{ width: 3, height: 20, background: color, borderRadius: 2, flexShrink: 0 }} />}
        <span style={{ fontSize: 15, fontWeight: 600, color: C.text }}>{title}</span>
        {subtitle && <span style={{ fontSize: 12, color: C.dim }}>{subtitle}</span>}
        <span style={{ marginLeft: "auto", fontSize: 12, color: C.dim }}>{done}/{items.length}</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {items.map(item => <PrepItemRow key={item.id} item={item} trip={trip} onToggle={onToggle} onDelete={onDelete} onUpdate={onUpdate} />)}
      </div>
    </div>
  );
}

function PrepItemRow({ item, trip, onToggle, onDelete, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ text: item.text, notes: item.notes, category: item.category, priority: item.priority });
  const prio = PREP_PRIO.find(p => p.id === item.priority) || PREP_PRIO[1];

  const scopeLabel = (() => {
    if (item.scope === "city") {
      const c = trip.cities.find(x => x.id === item.cityId);
      return c ? `🏙️ ${c.name}` : "🏙️ City";
    }
    if (item.scope === "day") {
      const c = trip.cities.find(x => x.id === item.cityId);
      const d = c?.days.find(x => x.id === item.dayId);
      return d ? `📅 ${c.name} · ${d.label}` : "📅 Day";
    }
    return null;
  })();

  return (
    <div style={{
      background: item.completed ? "transparent" : C.surface,
      border: `1px solid ${item.completed ? C.border : C.border}`,
      borderRadius: 10, padding: "11px 14px",
      opacity: item.completed ? 0.55 : 1, transition: "all 0.2s",
    }}>
      {!editing ? (
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
          <input type="checkbox" checked={!!item.completed} onChange={() => onToggle(item.id)}
            style={{ marginTop: 2, flexShrink: 0 }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <span style={{ fontSize: 14, color: C.text, textDecoration: item.completed ? "line-through" : "none", lineHeight: 1.4 }}>
              {item.text}
            </span>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4, alignItems: "center" }}>
              <Tag color={prio.color}>{prio.label}</Tag>
              <Tag color={C.mid}>{item.category}</Tag>
              {scopeLabel && item.scope !== "trip" && <Tag color={C.teal}>{scopeLabel}</Tag>}
              {item.fromTemplate && <Tag color={C.purple}>template</Tag>}
            </div>
            {item.notes && <div style={{ fontSize: 12, color: C.dim, marginTop: 5, fontStyle: "italic" }}>{item.notes}</div>}
          </div>
          <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
            <button onClick={() => setEditing(true)} style={{ background: "none", border: "none", color: C.dim, cursor: "pointer", fontSize: 13, padding: "2px 5px" }}>✏️</button>
            <button onClick={() => onDelete(item.id)} style={{ background: "none", border: "none", color: C.warn, cursor: "pointer", fontSize: 13, padding: "2px 5px" }}>✕</button>
          </div>
        </div>
      ) : (
        <div style={{ display: "grid", gap: 10 }}>
          <Input value={draft.text} onChange={v => setDraft(d => ({ ...d, text: v }))} placeholder="Item text..." />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <Sel label="Category" value={draft.category} onChange={v => setDraft(d => ({ ...d, category: v }))} options={PREP_CATS} />
            <Sel label="Priority" value={draft.priority} onChange={v => setDraft(d => ({ ...d, priority: v }))} options={PREP_PRIO.map(p => ({ value: p.id, label: p.label }))} />
          </div>
          <Input label="Notes" value={draft.notes} onChange={v => setDraft(d => ({ ...d, notes: v }))} placeholder="Notes..." />
          <div style={{ display: "flex", gap: 8 }}>
            <Btn variant="accent" size="sm" onClick={() => { onUpdate(item.id, draft); setEditing(false); }}>Save</Btn>
            <Btn variant="ghost"  size="sm" onClick={() => setEditing(false)}>Cancel</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   IMPORT TEMPLATE MODAL (trip-side)
═══════════════════════════════════════════════════════════════ */
function ImportTemplateModal({ trip, templates, onImport, onClose }) {
  const allTemplates = [...BUILTIN_TEMPLATES, ...templates];
  const [selected, setSelected] = useState(null);
  const [scope,    setScope]    = useState("trip");
  const [cityId,   setCityId]   = useState(trip.cities[0]?.id || "");
  const [dayId,    setDayId]    = useState("");
  const [preview,  setPreview]  = useState(false);

  const tpl = allTemplates.find(t => t.id === selected);
  const scopedCity = trip.cities.find(c => c.id === cityId);

  const doImport = () => {
    if (!tpl) return;
    const items = stampTemplateItems(tpl.items, tpl.id).map(item => ({
      ...item, scope,
      cityId: scope !== "trip" ? cityId || null : null,
      dayId:  scope === "day"  ? dayId  || null : null,
    }));
    onImport(items);
    onClose();
  };

  return (
    <div>
      <div style={{ padding: "22px 24px 0", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
          <div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, color: C.text }}>Import Checklist Template</h2>
            <p style={{ color: C.mid, fontSize: 13, marginTop: 3 }}>Choose a template and set its scope for this trip.</p>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
        </div>
        <div style={{ display: "flex", gap: 0, paddingTop: 12 }}>
          {[{ id: false, label: "Select" }, { id: true, label: "Preview" }].map(t => (
            <button key={String(t.id)} onClick={() => setPreview(t.id)} disabled={t.id && !tpl} style={{
              background: "none", border: "none", padding: "9px 18px", fontSize: 13, fontWeight: 500,
              cursor: t.id && !tpl ? "not-allowed" : "pointer",
              color: preview === t.id ? C.accent : C.mid, opacity: t.id && !tpl ? 0.4 : 1,
              borderBottom: `2px solid ${preview === t.id ? C.accent : "transparent"}`,
              transition: "all 0.15s",
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "20px 24px", maxHeight: "60vh", overflowY: "auto" }}>
        {!preview && (
          <>
            {/* Template grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              {allTemplates.map(t => (
                <button key={t.id} onClick={() => setSelected(t.id)} style={{
                  background: selected === t.id ? C.accentBg : C.surface2,
                  border: `1px solid ${selected === t.id ? C.accent : C.border}`,
                  borderRadius: 12, padding: "14px 16px", cursor: "pointer", textAlign: "left",
                  transition: "all 0.15s",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                    <span style={{ fontSize: 22 }}>{t.icon}</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{t.name}</span>
                    {t.isBuiltIn && <Tag color={C.teal}>built-in</Tag>}
                  </div>
                  <p style={{ fontSize: 12, color: C.mid, lineHeight: 1.5 }}>{t.description}</p>
                  <div style={{ marginTop: 8, fontSize: 11, color: C.dim }}>{t.items.length} items</div>
                </button>
              ))}
            </div>

            {/* Scope settings */}
            {selected && (
              <div style={{ background: C.surface2, borderRadius: 12, padding: 16, border: `1px solid ${C.accentBdr}`, animation: "fadeSlideIn 0.2s ease" }}>
                <h4 style={{ color: C.text, fontSize: 14, fontWeight: 600, marginBottom: 14 }}>Apply imported items to:</h4>
                <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                  {PREP_SCOPES.map(s => (
                    <button key={s.id} onClick={() => { setScope(s.id); setCityId(trip.cities[0]?.id || ""); setDayId(""); }} style={{
                      flex: 1, padding: "10px 8px", borderRadius: 10, cursor: "pointer",
                      background: scope === s.id ? C.accentBg : C.surface3,
                      border: `1px solid ${scope === s.id ? C.accent : C.border}`,
                      color: scope === s.id ? C.accent : C.mid, fontSize: 13, fontWeight: 500,
                      transition: "all 0.15s",
                    }}>{s.icon} {s.label}</button>
                  ))}
                </div>
                {scope !== "trip" && trip.cities.length > 0 && (
                  <Sel label="City" value={cityId} onChange={v => { setCityId(v); setDayId(""); }}
                    options={trip.cities.map(c => ({ value: c.id, label: c.name }))} />
                )}
                {scope === "day" && scopedCity?.days.length > 0 && (
                  <div style={{ marginTop: 12 }}>
                    <Sel label="Day" value={dayId} onChange={setDayId}
                      options={[{ value: "", label: "— Any day (unassigned) —" }, ...scopedCity.days.map(d => ({ value: d.id, label: `${d.label} — ${d.date}` }))]} />
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {preview && tpl && (
          <div style={{ animation: "fadeSlideIn 0.2s ease" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <span style={{ fontSize: 26 }}>{tpl.icon}</span>
              <div>
                <div style={{ fontSize: 16, fontWeight: 600, color: C.text }}>{tpl.name}</div>
                <div style={{ fontSize: 12, color: C.mid }}>{tpl.items.length} items</div>
              </div>
            </div>
            {PREP_CATS.map(cat => {
              const catItems = tpl.items.filter(i => i.category === cat);
              if (!catItems.length) return null;
              return (
                <div key={cat} style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 12, color: C.mid, fontWeight: 600, marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.04em" }}>{cat}</div>
                  {catItems.map(item => {
                    const prio = PREP_PRIO.find(p => p.id === item.priority) || PREP_PRIO[1];
                    return (
                      <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                        <div style={{ width: 6, height: 6, borderRadius: "50%", background: prio.color, flexShrink: 0 }} />
                        <span style={{ fontSize: 13, color: C.text, flex: 1 }}>{item.text}</span>
                        <Tag color={prio.color}>{prio.label}</Tag>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div style={{ padding: "14px 24px", borderTop: `1px solid ${C.border}`, display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        {preview && <Btn variant="ghost" onClick={() => setPreview(false)}>← Back</Btn>}
        {!preview && selected && <Btn variant="ghost" onClick={() => setPreview(true)}>Preview items →</Btn>}
        <Btn variant="accent" disabled={!selected} onClick={doImport}>
          Import {tpl ? `${tpl.items.length} items` : ""}
        </Btn>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TEMPLATE LIBRARY (home-screen global view)
═══════════════════════════════════════════════════════════════ */
function TemplateLibrary({ templates, onSave, onDelete, onClose }) {
  const [view,    setView]    = useState("list"); // list | edit
  const [editing, setEditing] = useState(null);   // null | template object
  const [newItem, setNewItem] = useState("");
  const [newCat,  setNewCat]  = useState("Other");
  const [newPrio, setNewPrio] = useState("normal");

  const allTpls = [...BUILTIN_TEMPLATES, ...templates];

  const startNew = () => {
    setEditing(newCustomTemplate({ name: "My Checklist", icon: "📋", description: "" }));
    setView("edit");
  };
  const startEdit = (tpl) => {
    if (tpl.isBuiltIn) {
      // Clone built-in as custom
      setEditing({ ...tpl, id: uid(), name: `${tpl.name} (copy)`, isBuiltIn: false, items: tpl.items.map(i => ({ ...i, id: uid() })) });
    } else {
      setEditing({ ...tpl, items: tpl.items.map(i => ({ ...i })) });
    }
    setView("edit");
  };

  const addEditItem = () => {
    if (!newItem.trim()) return;
    setEditing(e => ({ ...e, items: [...e.items, { id: uid(), text: newItem.trim(), category: newCat, priority: newPrio, notes: "" }] }));
    setNewItem("");
  };
  const removeEditItem = (id) => setEditing(e => ({ ...e, items: e.items.filter(i => i.id !== id) }));

  const saveTemplate = () => {
    if (!editing.name.trim()) return;
    onSave(editing);
    setView("list");
    setEditing(null);
  };

  const ICONS = ["📋","✅","🌍","🏖️","🚗","🎿","🏕️","🗺️","💼","🎒","🚢","🚂","🏔️","🌸"];

  return (
    <div>
      {/* Header */}
      <div style={{ padding: "22px 24px 0", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div>
            {view === "list" ? (
              <>
                <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: C.text }}>Checklist Templates</h2>
                <p style={{ color: C.mid, fontSize: 13, marginTop: 3 }}>Reusable lists you can import into any trip.</p>
              </>
            ) : (
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <button onClick={() => { setView("list"); setEditing(null); }} style={{ background: "none", border: "none", color: C.mid, cursor: "pointer", fontSize: 13 }}>← Templates</button>
                <span style={{ color: C.dim }}>·</span>
                <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 24, color: C.text }}>
                  {editing?.isBuiltIn === false && !templates.find(t => t.id === editing.id) ? "New Template" : "Edit Template"}
                </h2>
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {view === "list" && <Btn variant="accent" size="sm" onClick={startNew}>+ New Template</Btn>}
            <button onClick={onClose} style={{ background: "none", border: "none", color: C.dim, fontSize: 22 }}>×</button>
          </div>
        </div>
      </div>

      <div style={{ padding: "20px 24px", maxHeight: "72vh", overflowY: "auto" }}>

        {/* LIST VIEW */}
        {view === "list" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ fontSize: 12, color: C.dim, marginBottom: 4 }}>BUILT-IN</div>
            {BUILTIN_TEMPLATES.map(tpl => (
              <TemplateRow key={tpl.id} tpl={tpl} onEdit={() => startEdit(tpl)} isBuiltIn />
            ))}
            {templates.length > 0 && (
              <>
                <div style={{ fontSize: 12, color: C.dim, marginTop: 8, marginBottom: 4 }}>YOUR TEMPLATES</div>
                {templates.map(tpl => (
                  <TemplateRow key={tpl.id} tpl={tpl} onEdit={() => startEdit(tpl)} onDelete={() => onDelete(tpl.id)} />
                ))}
              </>
            )}
            {templates.length === 0 && (
              <div style={{ background: C.surface2, borderRadius: 10, padding: "16px", color: C.dim, fontSize: 13, textAlign: "center" }}>
                No custom templates yet. Create one or clone a built-in to get started.
              </div>
            )}
          </div>
        )}

        {/* EDIT VIEW */}
        {view === "edit" && editing && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Icon picker */}
            <Field label="Icon">
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {ICONS.map(ic => (
                  <button key={ic} onClick={() => setEditing(e => ({ ...e, icon: ic }))} style={{
                    fontSize: 22, padding: "6px 10px", borderRadius: 8, cursor: "pointer",
                    background: editing.icon === ic ? C.accentBg : C.surface2,
                    border: `1px solid ${editing.icon === ic ? C.accent : C.border}`,
                    transition: "all 0.1s",
                  }}>{ic}</button>
                ))}
              </div>
            </Field>
            <Input label="Template name" value={editing.name}
              onChange={v => setEditing(e => ({ ...e, name: v }))} placeholder="e.g., My Europe Checklist" />
            <Textarea label="Description (optional)" value={editing.description}
              onChange={v => setEditing(e => ({ ...e, description: v }))}
              placeholder="When would you use this list?" rows={2} />

            {/* Items */}
            <div>
              <div style={{ fontSize: 12, color: C.mid, fontWeight: 500, marginBottom: 10 }}>ITEMS ({editing.items.length})</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
                {editing.items.map(item => {
                  const prio = PREP_PRIO.find(p => p.id === item.priority) || PREP_PRIO[1];
                  return (
                    <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 8, background: C.surface2, borderRadius: 8, padding: "8px 12px", border: `1px solid ${C.border}` }}>
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: prio.color, flexShrink: 0 }} />
                      <span style={{ flex: 1, fontSize: 13, color: C.text }}>{item.text}</span>
                      <Tag color={C.mid}>{item.category}</Tag>
                      <Tag color={prio.color}>{prio.label}</Tag>
                      <button onClick={() => removeEditItem(item.id)} style={{ background: "none", border: "none", color: C.warn, cursor: "pointer", fontSize: 14, padding: "0 2px" }}>✕</button>
                    </div>
                  );
                })}
                {editing.items.length === 0 && <div style={{ color: C.dim, fontSize: 13, fontStyle: "italic", padding: "6px 0" }}>No items yet — add some below.</div>}
              </div>

              {/* Add item inline */}
              <div style={{ background: C.surface2, borderRadius: 10, padding: 14, border: `1px solid ${C.border}` }}>
                <div style={{ display: "grid", gap: 10 }}>
                  <input value={newItem} onChange={e => setNewItem(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && addEditItem()}
                    placeholder="Add item text (Enter to save)..." />
                  <div style={{ display: "flex", gap: 10 }}>
                    <div style={{ flex: 1 }}>
                      <select value={newCat} onChange={e => setNewCat(e.target.value)}>
                        {PREP_CATS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div style={{ flex: 1 }}>
                      <select value={newPrio} onChange={e => setNewPrio(e.target.value)}>
                        {PREP_PRIO.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
                      </select>
                    </div>
                    <Btn variant="accent" size="sm" onClick={addEditItem} disabled={!newItem.trim()}>Add</Btn>
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, paddingTop: 4 }}>
              <Btn variant="accent" onClick={saveTemplate} disabled={!editing.name.trim() || editing.items.length === 0}>
                Save Template
              </Btn>
              <Btn variant="ghost" onClick={() => { setView("list"); setEditing(null); }}>Cancel</Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function TemplateRow({ tpl, onEdit, onDelete, isBuiltIn }) {
  return (
    <div style={{ background: C.surface2, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 16px", display: "flex", alignItems: "center", gap: 14 }}>
      <span style={{ fontSize: 28, flexShrink: 0 }}>{tpl.icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: C.text }}>{tpl.name}</span>
          {isBuiltIn && <Tag color={C.teal}>built-in</Tag>}
        </div>
        <span style={{ fontSize: 12, color: C.mid }}>{tpl.description}</span>
        <span style={{ fontSize: 11, color: C.dim, marginLeft: 8 }}>· {tpl.items.length} items</span>
      </div>
      <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
        <Btn variant="ghost" size="sm" onClick={onEdit}>{isBuiltIn ? "Clone & Edit" : "Edit"}</Btn>
        {!isBuiltIn && onDelete && <Btn variant="danger" size="sm" onClick={onDelete}>Delete</Btn>}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ROOT APP
═══════════════════════════════════════════════════════════════ */
const STORAGE_KEY_TRIPS = "journey_trips_v1";
const STORAGE_KEY_TPLS  = "journey_templates_v1";
const loadTrips = () => { try { const r = localStorage.getItem(STORAGE_KEY_TRIPS); if (r) return JSON.parse(r); } catch {} return [SAMPLE]; };
const loadTemplates = () => { try { const r = localStorage.getItem(STORAGE_KEY_TPLS); if (r) return JSON.parse(r); } catch {} return []; };
const saveTrips     = (t) => { try { localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(t)); } catch {} };
const saveTemplates = (t) => { try { localStorage.setItem(STORAGE_KEY_TPLS,  JSON.stringify(t)); } catch {} };

export default function App() {
  const [trips,     setTrips]     = useState(loadTrips);
  const [templates, setTemplates] = useState(loadTemplates);
  const [view,    setView]    = useState("home");
  const [tripId,  setTripId]  = useState(null);
  const [cityId,  setCityId]  = useState(null);
  const [dayId,   setDayId]   = useState(null);
  const [cityTab, setCityTab] = useState("days");
  const [tripTab, setTripTab] = useState("itinerary");
  const [modal,   setModal]   = useState(null);
  useEffect(() => { saveTrips(trips); }, [trips]);
  useEffect(() => { saveTemplates(templates); }, [templates]);

  const trip = trips.find(t => t.id === tripId);
  const city = trip?.cities.find(c => c.id === cityId);
  const day  = city?.days.find(d => d.id === dayId);

  const setTrip  = fn => setTrips(ts => ts.map(t => t.id === tripId ? fn(t) : t));
  const setCity_ = (cid, fn) => setTrip(t => ({ ...t, cities: t.cities.map(c => c.id === cid ? fn(c) : c) }));
  const setDay_  = (cid, did, fn) => setCity_(cid, c => ({ ...c, days: c.days.map(d => d.id === did ? fn(d) : d) }));
  const setBlock = (cid, did, bl, fn) => setDay_(cid, did, d => ({ ...d, blocks: { ...d.blocks, [bl]: fn(d.blocks[bl]) } }));

  const goHome = () => { setView("home"); setTripId(null); };
  const goTrip = (tid) => {
    const t = trips.find(x => x.id === tid);
    setTripId(tid); setCityId(t?.cities[0]?.id ?? null);
    setView("trip"); setTripTab(t?.status === "active" ? "travel" : "itinerary");
    setCityTab("days");
  };
  const goDay  = (did) => { setDayId(did); setView("day"); };

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", background: C.bg, minHeight: "100vh", color: C.text }}>
      <style>{GLOBAL_CSS}</style>

      {view === "home" && (
        <HomeView trips={trips} onOpen={goTrip} onNew={() => setModal({ type: "newTrip" })}
          onImportExport={() => setModal({ type: "importExport" })}
          onTemplates={() => setModal({ type: "templateLibrary" })} />
      )}
      {view === "trip" && trip && (
        <TripView
          trip={trip} city={city}
          cityTab={cityTab} setCityTab={setCityTab}
          tripTab={tripTab} setTripTab={setTripTab}
          onBack={goHome}
          onSelectCity={cid => { setCityId(cid); setCityTab("days"); }}
          onOpenDay={goDay}
          mutateTrip={fn => setTrip(fn)}
          mutateCity={(cid, fn) => setCity_(cid, fn)}
          mutateDay={(cid, did, fn) => setDay_(cid, did, fn)}
          setModal={setModal}
          templates={templates}
        />
      )}
      {view === "day" && trip && city && day && (
        <DayView
          trip={trip} city={city} day={day}
          onBack={() => setView("trip")}
          addActivity={(bl, act)     => setBlock(cityId, dayId, bl, acts => [...acts, act])}
          updateActivity={(bl, id, upd) => setBlock(cityId, dayId, bl, acts => acts.map(a => a.id === id ? { ...a, ...upd } : a))}
          deleteActivity={(bl, id)   => setBlock(cityId, dayId, bl, acts => acts.filter(a => a.id !== id))}
          mutateDay={fn => setDay_(cityId, dayId, fn)}
          setModal={setModal}
        />
      )}

      {modal?.type === "templateLibrary" && (
        <Modal onClose={() => setModal(null)} maxWidth={680}>
          <TemplateLibrary
            templates={templates}
            onSave={tpl => setTemplates(ts => {
              const exists = ts.find(t => t.id === tpl.id);
              return exists ? ts.map(t => t.id === tpl.id ? tpl : t) : [...ts, tpl];
            })}
            onDelete={id => setTemplates(ts => ts.filter(t => t.id !== id))}
            onClose={() => setModal(null)}
          />
        </Modal>
      )}
      {modal?.type === "importTemplate" && (
        <Modal onClose={() => setModal(null)} maxWidth={640}>
          <ImportTemplateModal
            trip={trips.find(t => t.id === modal.tripId)}
            templates={templates}
            onImport={(items) => {
              setTrips(ts => ts.map(t => t.id === modal.tripId
                ? { ...t, prepChecklist: [...(t.prepChecklist || []), ...items] }
                : t
              ));
            }}
            onClose={() => setModal(null)}
          />
        </Modal>
      )}
      {modal?.type === "importExport" && (
        <Modal onClose={() => setModal(null)} maxWidth={580}>
          <ImportExportModal
            trips={trips}
            currentTrip={modal.trip || null}
            onImport={(imported, mode) => {
              if (mode === "replace") setTrips(imported);
              else setTrips(ts => [...ts, ...imported]);
            }}
            onClose={() => setModal(null)}
          />
        </Modal>
      )}
      {modal?.type === "newTrip" && (
        <Modal onClose={() => setModal(null)}>
          <NewTripModal onSave={t => { setTrips(ts => [...ts, t]); setModal(null); }} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal?.type === "newCity" && (
        <Modal onClose={() => setModal(null)}>
          <NewCityModal
            existingCities={modal.cities}
            onSave={c => { setTrips(ts => ts.map(t => t.id === modal.tripId ? { ...t, cities: [...t.cities, c] } : t)); setModal(null); }}
            onClose={() => setModal(null)}
          />
        </Modal>
      )}
    </div>
  );
}
